#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <libgen.h>
#include <unistd.h>
#include <sys/uio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <libcapsicum.h>


int
recv_int_rpc(struct lc_host* host, u_int32_t* op_buf, u_int32_t* seq_op_buf)
{
    int* num_fds_buf;
    size_t num_size;
    lcs_recvrpc(
            host, op_buf, seq_op_buf, (u_char**) &num_fds_buf, &num_size);
    return *num_fds_buf;
}

/* int checkifexecutable(const char *filename)
 * 
 * Return non-zero if the name is an executable file, and
 * zero if it is not executable, or if it does not exist.
 */

int checkifexecutable(const char *filename)
{
     int result;
     struct stat statinfo;
     
     result = stat(filename, &statinfo);
     if (result < 0) return 0;
     if (!S_ISREG(statinfo.st_mode)) return 0;

     if (statinfo.st_uid == geteuid()) return statinfo.st_mode & S_IXUSR;
     if (statinfo.st_gid == getegid()) return statinfo.st_mode & S_IXGRP;
     return statinfo.st_mode & S_IXOTH;
}


/* int findpathof(char *pth, const char *exe)
 *
 * Find executable by searching the PATH environment variable.
 *
 * const char *exe - executable name to search for.
 *       char *pth - the path found is stored here, space
 *                   needs to be available.
 *
 * If a path is found, returns non-zero, and the path is stored
 * in pth.  If exe is not found returns 0, with pth undefined.
 */

int findpathof(char *pth, const char *exe)
{
     char *searchpath;
     char *beg, *end;
     int stop, found;
     int len;

     if (strchr(exe, '/') != NULL) {
	  if (realpath(exe, pth) == NULL) return 0;
	  return  checkifexecutable(pth);
     }

     searchpath = getenv("PATH");
     if (searchpath == NULL) return 0;
     if (strlen(searchpath) <= 0) return 0;

     beg = searchpath;
     stop = 0; found = 0;
     do {
	  end = strchr(beg, ':');
	  if (end == NULL) {
	       stop = 1;
	       strncpy(pth, beg, PATH_MAX);
	       len = strlen(pth);
	  } else {
	       strncpy(pth, beg, end - beg);
	       pth[end - beg] = '\0';
	       len = end - beg;
	  }
	  if (pth[len - 1] != '/') strncat(pth, "/", 1);
	  strncat(pth, exe, PATH_MAX - len);
	  found = checkifexecutable(pth);
	  if (!stop) beg = end + 1;
     } while (!stop && !found);
	  
     return found;
}

struct lc_sandbox* basic_start_sb(const char* sb_name, char* const argv[])
{
    struct lc_sandbox* sandbox;
    char full_path[PATH_MAX];
    int exe_found = findpathof(full_path, sb_name);
    if (!exe_found)
    {
        fprintf(
            stderr,
            "capweave runtime: sandbox not found in path. Aborting.\n");
        abort();
    }

    int worker_start_status =
        lch_start(
            full_path,
            argv,
            LCH_PERMIT_STDOUT | LCH_PERMIT_STDERR,
            0,
            &sandbox);

    // Check that the worker was started successfully.
    if (worker_start_status == -1) {
        fprintf(stderr, "wag: error starting sandbox. Aborting.\n");
        abort();
    }

    return sandbox;
}

// unblock_host: unblock the host by acking the RPC.
void unblock_host(struct lc_host* host, u_int32_t op, u_int32_t seq_op)
{
    lcs_sendrpc(host, op, seq_op, NULL, 0);
    return;
}

void* sb_recv_buf(struct lc_host* host, size_t size) {
    void* buf = malloc(size);
    fflush(stdout);
    lcs_recv(host, buf, size, 0);
    return buf;
}

int sb_recv_int(struct lc_host* host)
{
    int res;
    lcs_recv(host, &res, sizeof(int), 0);
    return res;
}

size_t sb_recv_size(struct lc_host* host)
{
    size_t res;
    lcs_recv(host, &res, sizeof(res), 0);
    return res;
}

void
sb_recv_virt_table(
    struct lc_host* host, int num_descs, int** virts, int** descs)
{
    // DBG: int padded_count = num_descs + 1;
    int padded_count = num_descs + 1;
    *virts = (int*) malloc(num_descs * sizeof(int));
    *descs = (int*) malloc(num_descs * sizeof(int));
    lcs_recv_rights(
            host,
            *virts,
            num_descs * sizeof(int),
            0,
            *descs,
            &padded_count);

	// printf("sb_recv_virt_table: num descs: %d\n", num_descs);
	for (int i = 0; i < num_descs; i++)
	{
		// printf("virt: %d, desc %d\n", (*virts)[i], (*descs)[i]);
	}

    return;
}

void sb_send_buf(struct lc_host* host, void* buf, size_t sz)
{
    // Send information to the host.
    size_t num_sent = lcs_send(host, buf, sz, 0);
    if (num_sent != sz)
    {
        fprintf(stderr, "sb_send_buf: send failed\n");
        abort();
    }

    return;
}

void sb_send_int(struct lc_host* host, int i)
{
    size_t num_sent = lcs_send(host, &i, sizeof(int), 0);
    if (num_sent != sizeof(int))
    {
        fprintf(stderr, "sb_send_int: send failed\n");
        abort();
    }

    return;
}

void sb_send_size(struct lc_host* host, size_t sz)
{
    size_t num_sent = lcs_send(host, &sz, sizeof(size_t), 0);
    if (num_sent != sizeof(size_t))
    {
        fprintf(stderr, "sb_send_size: send failed\n");
        abort();
    }

    return;
}

void
sb_send_virt_table(struct lc_host* host, int* descs, int num_descs)
{
	ssize_t desc_bytes = num_descs * sizeof(int);
	int odd_descs = num_descs % 2;
	int num_padded = num_descs + odd_descs;
	int buf[num_padded];
	memcpy(buf, descs, num_descs * sizeof(int));
	if (odd_descs) {
		buf[num_descs] = descs[0];
	}

    ssize_t bytes_sent = 
            lcs_send_rights(
                    host,
                    descs,
					desc_bytes,
                    0, // flags
                    buf,
                    num_padded);

    if (bytes_sent != desc_bytes)
    {
        fprintf(stderr, "sb_send_virt_table: send failed\n");
        abort();
    }

    return;
}

void
sb_send_virt_table2(struct lc_host* host, int* descs, int num_descs)
{
	ssize_t desc_bytes = num_descs * sizeof(int);
    ssize_t bytes_sent = 
            lcs_send_rights(
                    host,
                    descs,
					desc_bytes,
                    0, // flags
                    descs,
                    num_descs);

    if (bytes_sent != desc_bytes)
    {
        fprintf(stderr, "sb_send_virt_table: send failed\n");
        abort();
    }

    return;
}


void
sb_send_virt_table3(struct lc_host* host, int* descs, int num_descs)
{
	int* cur_desc = descs;
	int buf[2];
	for (int i = 0; i < num_descs; i++)
	{
		buf[0] = *cur_desc;
		buf[1] = *cur_desc;
		lcs_send_rights(
				host,
				cur_desc,
				sizeof(int),
				0, // flags
				buf,
				2);
		cur_desc++;
	}

    return;
}


int rpc_int(struct lc_sandbox* sb, int worker, int i)
{       
    struct iovec num_vec;
    num_vec.iov_base = &i;
    num_vec.iov_len = sizeof(int);

    /* Make an RPC call passing the number of file descriptors. */
    size_t rlp;
    fflush(stdout);
    int rpc_status = 
        lch_rpc(sb,
                worker,
                &num_vec,
                1,
                0,
                0,
                &rlp);
    fflush(stdout);

    /*
    if (rpc_status < 0) {
        // RPC threw an error.
        fprintf(stderr, "cw_rpc: lch_rpc committed an error. Aborting.\n");
        fflush(stderr);
        abort();
    }
    */

    return rpc_status;
}

void* host_recv_buf(struct lc_sandbox* sb, size_t sz)
{
    void* buf = malloc(sz);
    lch_recv(sb, buf, sz, 0);
    return buf;
}

int host_recv_int(struct lc_sandbox* sb)
{
    int i;
    lch_recv(sb, &i, sizeof(int), 0);
    return i;
}

size_t host_recv_size(struct lc_sandbox* sb)
{
    size_t sz;
    lch_recv(sb, &sz, sizeof(size_t), 0);
    return sz;
}

int
host_recv_virt_table(
	struct lc_sandbox* sb, int num_descs, int** virts, int** descs)
{
	int odd_descs = num_descs % 2;
	int recvd = num_descs + odd_descs;
    *virts = (int*) malloc(num_descs * sizeof(int));
    *descs = (int*) malloc(recvd * sizeof(int));
    lch_recv_rights(
        sb,
        *virts,
        num_descs * sizeof(int),
        0,
        *descs,
        &recvd);

	if (odd_descs)
	{
		close((*descs)[num_descs]);
	}

    return num_descs;
}

int
host_recv_virt_table2(
	struct lc_sandbox* sb, int num_descs, int** virts, int** descs)
{

    *virts = (int*) malloc(num_descs * sizeof(int));
    *descs = (int*) malloc(num_descs * sizeof(int));
    // DBG: int tampered = num_descs + 1;
    int recvd = num_descs;
    lch_recv_rights(
        sb,
        *virts,
        num_descs * sizeof(int),
        0,
        *descs,
        &recvd);

    return recvd;
}


int
host_recv_virt_table3(
	struct lc_sandbox* sb, int num_descs, int** virts, int** descs)
{

    *virts = (int*) malloc(num_descs * sizeof(int));
    *descs = (int*) malloc(num_descs * sizeof(int));
	int* cur_virt = *virts;
	int* cur_desc = *descs;
    // DBG: int tampered = num_descs + 1;
	int buf[2];
	for (int i = 0; i < num_descs; i++)
	{
		int recvd = 2;
		lch_recv_rights(
			sb,
			cur_virt,
			sizeof(int),
			0,
			buf,
			&recvd);
		cur_virt++;
		*cur_desc = buf[0];
		close(buf[1]);
		cur_desc++;
	}

    return num_descs;
}


void host_send_buf(struct lc_sandbox* sb, void* buf, size_t len)
{
    ssize_t bytes_sent = lch_send(sb, buf, len, 0);
    if (bytes_sent != len)
    {
        fprintf(stderr, "host_send_buf: error\n");
        abort();
    }

    return;
}

int host_send_int(struct lc_sandbox* sb, int i)
{
    ssize_t bytes_sent = lch_send(sb, &i, sizeof(int), 0);
	return !(bytes_sent == sizeof(int));
}

void host_send_size(struct lc_sandbox* sb, size_t sz)
{
    ssize_t bytes_sent = lch_send(sb, &sz, sizeof(size_t), 0);
    if (bytes_sent != sizeof(size_t))
    {
        fprintf(stderr, "host_send_buf: error\n");
        abort();
    }
    return;
}

int
host_send_virt_table(struct lc_sandbox* sb, int* fds, int num_fds)
{
	int fd_bytes = num_fds * sizeof(int);
    ssize_t bytes_sent =
        lch_send_rights(
            sb,
            fds,
			fd_bytes,
            0,
            fds,
            num_fds);

    return bytes_sent != fd_bytes;
}

