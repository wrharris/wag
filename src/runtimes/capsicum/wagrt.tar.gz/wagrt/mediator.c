// Include C libs.
#include <fcntl.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// Include libcapsicum.
#include <libcapsicum.h>

// Include our libcapsicum extensions.
#include "autolibcapsicum.h"

int main(int argc, char* argv[]) {
    // Get the host object that identifies us.
    argv[1] = "/home/capsicum/wvd/php-5.3.2/auto-wvd";
    printf(
        "mediator: argc: %d, arg 0: %s, arg 1: %s\n",
        argc,
        argv[0],
        argv[1]);
    fflush(stdout);
    struct lc_host* host;
    int get_status = lcs_get(&host);
    char* const sb_argv[2] = { argv[1], NULL };
    char* const sb_argv_2[2] = { "/home/capsicum/wvd/php-5.3.2/auto-wvd.2", NULL };
    int done = 0;
    
    // Poll for RPC requests.
    while (1) {
        // Get the next RPC request.
        u_int32_t op;
        u_int32_t seq_op;
        printf("med: pre recv num fds\n");
        fflush(stdout);
        int num_fds = recv_int_rpc(host, &op, &seq_op);

        // Unblock the host.
        printf("med: pre unblock client\n");
        fflush(stdout);
        unblock_host(host, op, seq_op);

        // Start a sandbox running the instrumented program.
        printf("med %d: pre start sandbox: %s\n", getpid(), argv[1]);
        fflush(stdout);
        struct lc_sandbox* sb;
        if (!done) {
            sb = basic_start_sb(argv[1], sb_argv);
        }
        else
        {
            sb = basic_start_sb("./auto-wvd.2", sb_argv_2);
        }

        if (!sb)
        {
            fprintf(stderr, "error starting sandbox\n");
            abort();
        }

        /* Make an RPC to our sandbox that passes the number of file
         * descriptors. */
        printf("med %d: pre rpc\n", getpid());
        fflush(stdout);
        if (!done) {
            rpc_int(sb, op, num_fds);
            done = 1;
        }

        /* Forward the serialized virtual descriptor table from the host
         * to the worker. */
        int* fds;
        int* virts;
        printf("med %d: pre recv virt table\n", getpid());
        fflush(stdout);
        sb_recv_virt_table(host, num_fds, &virts, &fds);
        printf("med: pre send virt table\n");
        fflush(stdout);
        host_send_virt_table(sb, virts, fds, num_fds);

        // Forward the number of arguments. */
        printf("med: pre recv num args\n");
        fflush(stdout);
        int num_args = sb_recv_int(host);
        printf("med: pre send num args: %d\n", num_args);
        fflush(stdout);
        host_send_int(sb, num_args);

        // For each argument:
        int i;
        for (i = 0; i < num_args; i++) {
            // Forward the size of the argument.
            printf("med: pre recv arg size\n");
            size_t arg_size = sb_recv_size(host);
            printf("med: pre send arg size: %ld\n", arg_size);
            host_send_size(sb, arg_size);

            // Foward the argument.
            printf("med: pre recv arg\n");
            void* arg_buf = sb_recv_buf(host, arg_size);
            printf("med: pre send arg\n");
            fflush(stdout);
            host_send_buf(sb, arg_buf, arg_size);
        }

        // Forward back the number of descriptors.
        printf("med %d: pre recv ret num fds\n", getpid());
        fflush(stdout);
        int num_ret_fds = host_recv_int(sb);
        printf("med: pre send ret num fds: %d\n", num_ret_fds);
        sb_send_int(host, num_ret_fds);

        // Forward back the serialized descriptor table.
        int* ret_virts;
        int* ret_descs;
        printf("med: pre recv virt table\n");
        fflush(stdout);
        host_recv_virt_table(sb, num_ret_fds, &ret_virts, &ret_descs);
        printf("med: pre send virt table\n");
        fflush(stdout);
        sb_send_virt_table(host, ret_virts, ret_descs, num_ret_fds);

        // Forward back the size of the return value.
        printf("med: pre recv ret size\n");
        fflush(stdout);
        size_t ret_size = host_recv_size(sb);
        printf("med: pre send ret size: %ld\n", ret_size);
        fflush(stdout);
        sb_send_size(host, ret_size);

        // Forward back the return buffer.
        printf("med: pre recv ret buf\n");
        fflush(stdout);
        void* ret_buf = host_recv_buf(sb, ret_size);
        printf("med: pre send ret buf\n");
        fflush(stdout);
        sb_send_buf(host, ret_buf, ret_size);
        printf("med: post send return buf\n");
        fflush(stdout);

        // Forward back the strategy state.
        int strat_state = host_recv_int(sb);
        sb_send_int(host, strat_state);

        // Stop the sandbox.
        printf("pre stop sandbox\n");
        fflush(stdout);
        lch_stop(sb);
        printf("post stop sandbox\n");
        fflush(stdout);
    }

    return 0;
}
