// Debugging flags.
#define EN_CAPENTER 0
#define EN_FORK 0
#define EN_LC_LIMITFD 0
#define EN_RPC 1

// Include C++ STL map.
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <string>

// Include C libs.
#include <pcap.h>
#include <fcntl.h>
#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <poll.h>
#include <sys/errno.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/uio.h>
#include <sys/wait.h>
#include <unistd.h>

// Include Capsicum.
#include <sys/capability.h>
#include <libcapsicum.h>

// Include library for automatic marshalling into libcapsicum.
#include "autolibcapsicum.h"

// state: the state of the weaver
typedef int state_t;

// prog_comm_indx_t: an index of a program command
typedef int action_indx_t;

/* prog_block_indx_t: an index of a successor instruction that signals a
 * completed internal action. */
typedef int succ_indx_t;

// internal_indx_t: an index of an internal action.
typedef int internal_indx_t;

// prog_call_indx_t: an index of a call.
typedef int call_indx_t;

// prim_ptr: a pointer to a host primitive to execute
typedef void(*prim_ptr)();

/* Support RPC. First, a map from each work function to its
 * unmarshaller. */
typedef void* marshaller_ptr;

typedef iovec* (*unmarshaller_ptr)(iovec*);

/* Each of the following transition matrices is a stub that allows the
 * library to compile. Each is redeclared as a multidemensional array
 * and initialized by the policy-weaver generator.
 */

// Parallel arrays relating LLVM instructions to internal actions.
extern action_indx_t int_acts[];

extern succ_indx_t int_succs[];

// Parallel arrays representing the internal transition function.
extern state_t int_trans_pres[];

extern internal_indx_t int_trans_acts[];

extern prim_ptr int_trans_prims[];

extern state_t int_trans_posts[];

// Parallel arrays representing the call transition function.
extern prim_ptr call_trans_prims[];

extern state_t call_trans_posts[];

extern void* strat_calls_arr[];

// Parallel arrays representing the return transition function.
extern state_t ret_trans_pres[];

extern state_t ret_trans_stacks[];

extern prim_ptr ret_trans_prims[];

extern state_t ret_trans_posts[];

// Parallel arrays representing RPC data structures.
extern marshaller_ptr marshall_arr[];

extern unmarshaller_ptr unmarshall_arr[];


// Number of strategy objects.
extern int num_internals;
extern int num_calls;
extern int num_int_trans;
extern int num_ret_trans;

using namespace std;

// instr_pair: a pair of instructions.
typedef
struct instr_pair_s
{
  action_indx_t act;
  succ_indx_t succ;
} instr_pair;

string int_to_string(int i)
{
  return static_cast<ostringstream*>(&(ostringstream() << i))->str();
}

int dbg_threshold = -1;

void printd(int prio, const char* fmt, ...);

// printd: debug printer.
void printd(int prio, const char* fmt, ...)
{
    // If the priority is less than the threshold: 
    va_list fmt_args;
    va_start(fmt_args, fmt);

    if (prio <= dbg_threshold) {
        vprintf(fmt, fmt_args);
        va_end(fmt_args);
    }

    return;
}

int compare_ints(int a, int b)
{
  if (a < b) {
    return -1;
  }
  else if (a > b) {
    return 1;
  }
  else {
    return 0;
  }
}
               
bool operator<(const instr_pair& a, const instr_pair& b)
{
  int act_cmp = compare_ints(a.act, b.act);
  if (act_cmp != 0) {
    return act_cmp < 0;
  }
  else {
    return compare_ints(a.succ, b.succ) < 0;
  }
}

// internal_pre: prefix of an internal transition.
typedef
struct internal_pre_s
{
  state_t pre_state;
  internal_indx_t internal;
} internal_pre;

bool operator<(const internal_pre& a, const internal_pre& b)
{
  int pre_cmp = compare_ints(a.pre_state, b.pre_state);
  if (pre_cmp != 0) {
    return pre_cmp < 0;
  }
  else {
    return compare_ints(a.internal, b.internal) < 0;
  }
}

// trans_post: effect of a transition.
typedef
struct trans_post_s
{
  prim_ptr trans_prim;
  state_t trans_post_state;
} trans_post;

// return_pre: prefix of a return transition.
typedef
struct return_pre_s
{
  state_t pre;
  state_t stack;
} return_pre;

bool operator<(const return_pre& a, const return_pre& b)
{
  int pre_cmp = compare_ints(a.pre, b.pre);
  if (pre_cmp != 0) {
    return pre_cmp < 0;
  }
  else {
    return compare_ints(a.stack, b.stack) < 0;
  }
}

// strat_frame: an "activation record" of the strategy.
typedef
struct strat_frame_h
{
  state_t state;
  action_indx_t act;
  struct strat_frame_h* prev;
} strat_frame;

iovec* (*setup_func)(call_indx_t, iovec*, int);

/* instrs_to_internal: a map from pairs of instructions to internal
 * actions. */
using namespace std;
map<instr_pair, internal_indx_t> instrs_to_internal;

/* internal_trans: map representation of the internal transition
 * function. */
map<internal_pre, trans_post> internal_trans;

// call_trans: map representation of the call transition function.
map<call_indx_t, trans_post> call_trans;

/* strat_calls: the calls that are relevant to the strategy. */
set<void*> strat_calls;

// return_trans: map representation of the return transition function.
map<return_pre, trans_post> return_trans;

/* strat_stack: the stack of the strategy. */
strat_frame* strat_stack = NULL;

map<void*, marshaller_ptr> worker_marshaller;

map<call_indx_t, unmarshaller_ptr> worker_unmarshaller;

FILE* log;

/* trans_func: takes a pointer to a work function and translates to
 * a pointer to a function that potentially traps into a fork. */
void* (*trans_func)(void*);

extern "C" {

 /* void_ptr_id: the identity function over void*. */
  void* void_ptr_id(void* x)
  {
    printd(1, "void_ptr_id: execute\n");
    return x;
  }

  /* repl_marshaller: replace a function pointer with its marshaller.
   */
  void* repl_marshaller(void* x)
  {
    void* res;
    if (strat_calls.count(x) == 0) {
      res = x;
    }
    else {
      res = worker_marshaller[x];
    }

    return res;
  }

    struct lc_sandbox* sandbox;

    // fork_writer: the writer function for the fork.
    int fork_write_fd;
    void fork_buf_writer(void* buf, size_t len) {
        write(fork_write_fd, buf, len);
        return;
    }

    /* fork_desc_writer: function for writing back descriptors over forks.
     * Doesn't actually try to write descriptors over a fork. */
    void fork_desc_writer(int x) {
        return;
    }

    void fork_int_writer(int i)
    {
        write(fork_write_fd, &i, sizeof(int));
        return;
    }

    void fork_size_writer(size_t sz)
    {
        write(fork_write_fd, &sz, sizeof(size_t));
        return;
    }

    typedef void buf_writer(void*, size_t);
    typedef void desc_writer(int);
    typedef void int_writer(int);
    typedef void size_writer(size_t);

    // rpc_buf_writer: writes a buffer over an RPC.
    void rpc_buf_writer(void* buf, size_t len) {
        lc_host* host;
        int get_status = lcs_get(&host);

        // Get the host.
        if (get_status) {
          // Failed to get host.
          fprintf(stderr, "sandbox: failed to get host. Aborting.\n");
          abort();
        }

        sb_send_buf(host, buf, len);
        return;
    }

	int MAX_DESCS = getdtablesize();

	// collect_descs: collect the set of all descriptors that are open.
	int collect_descs(int sock, int** descs)
	{
		*descs = (int*) malloc(MAX_DESCS * sizeof(int));
		int num_descs = 0;
		for (int i = 0; i < MAX_DESCS; i++)
		{
			// is_fd: i is a file descriptor.
			errno = 0;
			bool is_fd = 
				(i != sock) && (fcntl(i, F_GETFL) != -1 || errno != EBADF);
			if (is_fd) 
			{
				(*descs)[num_descs++] = i;
			}
		}

		return num_descs;
	}

    /* rpc_desc_writer: function for writing back descriptors over RPCs.
    * Serializes the descriptor table. */
    void rpc_desc_writer(int sb_sock) {
        lc_host* host;
        int get_status = lcs_get(&host);
		int sock;
		lcs_getsock(host, &sock);
        int* descs;
		int num_descs = collect_descs(sock, &descs);

		/* Dup out any fds that clash with the sandbox socket. */
		for (int i = 0; i < num_descs; i++) {
			if (descs[i] == sock) {
				int fresh_desc = dup(descs[i]);
				close(descs[i]);
				descs[i] = fresh_desc;
			}
		}

		// Reinstate the sandbox socket.
		dup2(sb_sock, sock);

        if (get_status) {
            // Failed to get host.
            fprintf(stderr, "sandbox: failed to get host. Aborting.\n");
            abort();
        }

        // Send number of descriptors.
		printd(1, "rpc_desc_writer: pre send num descs\n");
        sb_send_int(host, num_descs);

        // Send the virtual descriptor table.
		printd(1, "rpc_desc_writer: pre send virt table\n");
		for (int i = 0; i < num_descs; i++)
		{
			fprintf(log, "server: desc %d: %d\n", i, descs[i]);
		}

        sb_send_virt_table(host, descs, num_descs);

		fprintf(log, "server: sent desc table\n");
		free(descs);
        return;
    }

    void rpc_int_writer(int i)
    {
        lc_host* host;
        int get_status = lcs_get(&host);
        if (get_status) {
            // Failed to get host.
            fprintf(stderr, "sandbox: failed to get host. Aborting.\n");
            abort();
        }

        sb_send_int(host, i);
        return;
    }

    void rpc_size_writer(size_t sz)
    {
        lc_host* host;
        int get_status = lcs_get(&host);
        if (get_status) {
            // Failed to get host.
            fprintf(stderr, "sandbox: failed to get host. Aborting.\n");
            abort();
        }

        sb_send_size(host, sz);
        return;
    }

    /* work_and_write: do the work and write it out. */
    void work_and_write(
		int cur_sb_sock,
        call_indx_t worker,
        iovec* args,
        buf_writer buf_writr,
        desc_writer desc_writr,
        int_writer int_writr,
        size_writer size_writr)
    {
        // Lookup the unmarshaller for the work function.
        unmarshaller_ptr unmarsh = worker_unmarshaller[worker];

        // Call the unmarshaller to do the work.
		fprintf(log, "server: pre work\n");
		fflush(log);
        iovec* res = (*unmarsh)(args);

		// Restore the sandbox socket.
        // Write the descriptor table back to the parent.
        fprintf(log, "server: pre write descs\n");
		fflush(log);
        desc_writr(cur_sb_sock);

        /* Write the size of the return value. */
        printd(1, "server: pre write size of ret: %ld\n", res->iov_len);
        size_writr(res->iov_len);

        /* Write the return value. */
        printd(1, "server: pre write res\n");
        buf_writr(res->iov_base, res->iov_len);

        /* Write the strategy state back to the parent. */
        printd(1, "server: pre write strategy state: %d\n",
               strat_stack->state);
        int_writr(strat_stack->state);
        return;
  }

  int init_descs(int* locals, int* descs, int num_descs)
  {
	lc_host* host;
	int get_status = lcs_get(&host);
	int sb_sock;
	lcs_getsock(host, &sb_sock);
	// printf("init_descs: sock: %d\n", sb_sock);
	for (int i = 0; i < num_descs; i++)
	{
		// printf("init_descs: %d, %d\n", descs[i], locals[i]);
		// DBG:
		errno = 0;
		if (locals[i] == sb_sock) {
			int tmp_sock = dup(sb_sock);
			close(sb_sock);
			sb_sock = tmp_sock;
		}
		dup2(descs[i], locals[i]); 
		close(descs[i]);
	}

	return sb_sock;
  }

  /* serve_req: poll, servicing requests. */
  void serve_req() {
    // Fetch the host object.
    lc_host* host;
    int get_status = lcs_get(&host);
    if (get_status) {
      // Failed to get host.
      fprintf(stderr, "sandbox: failed to get host. Aborting.\n");
      abort();
    }

    // Recv an RPC request.
    u_int32_t op;
    u_int32_t seq_op;
    int num_descs = recv_int_rpc(host, &op, &seq_op);

    // Unblock the parent.
    unblock_host(host, op, seq_op);

    // Read the file descriptors from the parent.
    int* locals;
    int* fds;
    sb_recv_virt_table(host, num_descs, &locals, &fds);

    // Read the number of arguments.
    int num_args = sb_recv_int(host);
    struct iovec* args =
        (struct iovec*) malloc(sizeof(struct iovec) * num_args);
    for (int arg_indx = 0; arg_indx < num_args; arg_indx++) {
        printd(1, "server: pre recv arg size\n");
        fflush(stdout);
        size_t arg_size = sb_recv_size(host);
        printd(1, "server: arg size %d\n", arg_size);
        printd(1, "server: pre recv arg\n");
        fflush(stdout);
        void* arg_buf = sb_recv_buf(host, arg_size);
        printd(1, "server: post recv arg\n");
        fflush(stdout);
        args[arg_indx].iov_base = arg_buf;
        args[arg_indx].iov_len = arg_size;
    }

    int sb_sock = init_descs(locals, fds, num_descs);

    // Do the work and write it back to the RPC caller.
    work_and_write(
		sb_sock,
        op,
        args,
        rpc_buf_writer,
        rpc_desc_writer,
        rpc_int_writer,
        rpc_size_writer);
	free(args);
    return;
  }

  void hang(int x) {
		while (1) {
		}
		return;
	}


  /* wg_init_strat: populate the transition maps with entries from the
   * array generated by LLVM.
   */
  void wg_init_strat(char* bin_name) {
	// DBG: open a log file for debugging.
	char* log_nm;
	if (ld_insandbox()) {
		log_nm = "/tmp/apache_server.txt";
	} else {
		log_nm = "/tmp/apache_client.txt";
	}
	
	log = fopen(log_nm, "a");
	fprintf(log, "wg_init_strat: begin\n");
	fflush(log);
	

    instrs_to_internal = map<instr_pair, internal_indx_t>();
    for (int i = 0; i < num_internals; i++) {
      instr_pair int_instrs = { int_acts[i], int_succs[i] };
      instrs_to_internal.insert(
        pair<instr_pair, internal_indx_t>(int_instrs,
                                                                  i));
    }

    // Populate the internal transition function.
    internal_trans = map<internal_pre, trans_post>();
    for (int i = 0; i < num_int_trans; i++) {
      internal_pre cur_pre = { int_trans_pres[i], int_trans_acts[i] };
      trans_post cur_post = { int_trans_prims[i], int_trans_posts[i] };
      internal_trans.insert(pair<internal_pre, trans_post>(cur_pre,
                                                           cur_post));
    }

    // Populate the call transition function.
    strat_calls = set<void*>();
    call_trans = map<call_indx_t, trans_post>();
    for (int i = 0; i < num_calls; i++) {
      trans_post cur_post = { call_trans_prims[i], call_trans_posts[i] };
      strat_calls.insert(strat_calls_arr[i]);
      strat_calls.insert(marshall_arr[i]);
      call_trans.insert(pair<call_indx_t, trans_post>(i, cur_post));
    }

    strat_calls.erase(0);

    // Populate the return transition function.
    return_trans = map<return_pre, trans_post>();
    for (int i = 0; i < num_ret_trans; i++) {
      return_pre cur_pre = { ret_trans_pres[i], ret_trans_stacks[i] };
      trans_post cur_post = { ret_trans_prims[i], ret_trans_posts[i] };
      return_trans.insert(pair<return_pre, trans_post>(cur_pre, cur_post));
    }

    // Populate maps used by fork and RPC.
    worker_marshaller = map<void*, marshaller_ptr>();
    worker_unmarshaller = map<int, unmarshaller_ptr>();
    for (int i = 0; i < num_calls; i++) {
      worker_marshaller.insert(pair<void*, marshaller_ptr>
                               (strat_calls_arr[i], marshall_arr[i]));
      worker_unmarshaller.insert(pair<int, unmarshaller_ptr>
                                 (i, unmarshall_arr[i]));
    }

    trans_func = void_ptr_id;

    if (ld_insandbox()) {
        // This process is in a sandbox. Fork and serve requests.
        while (1)
        {
            fprintf(log, "proc %d: fork new worker\n", getpid());
			fflush(log);
            pid_t p = fork();
            if (!p)
            {
                serve_req();
                exit(0);
            }
            else
            {
                int status;
                waitpid(p, &status, 0);
            }
        }
    }
    else {
        // This process is not a sandbox. Launch a sandbox.
        printd(1, "not in sandbox\n");
        char* const sandbox_argv[2] = { bin_name, NULL };
		fprintf(log, "launching sandbox bin: %s\n", bin_name);
        sandbox = basic_start_sb(bin_name, sandbox_argv);
		fprintf(log, "launched sandbox without abort\n");
		if (!sandbox) {
			fprintf(log, "sandbox is null\n");
			abort();
		}
    }

    printd(1, "wg_init_strat: end\n");
    return;
  }

  void wg_read_internal(internal_indx_t int_ind)
  {
    // Lookup the post-state and primitive.
    printd(2, "wg_read_internal %d: begin\n", int_ind);
    printd(2, "wg_read_internal: stack state: %d\n", strat_stack->state);
    internal_pre int_pre = { strat_stack->state, int_ind };
    trans_post int_post = internal_trans[int_pre];

    // Invoke the next primitive.
	printd(2,
		"wg_read_internal: %x, %d\n",
		int_post.trans_prim, int_post.trans_post_state);
    (*(int_post.trans_prim))();

    // Update the strategy state.
	printd(2, "post execute primitive\n");
	fflush(stdout);
    strat_stack->state = int_post.trans_post_state;
    printd(2, "wg_read_internal: end\n");
	fflush(stdout);
    return;
  }

  /* wg_read_action: read a program action. */
  void wg_read_action(action_indx_t cur_action)
  {
    printd(2, "wg_read_action: %d\n", cur_action);
	strat_stack->act = cur_action;
    return;
  }

  /* wg_read_succ: read the successor that closes an action. */
  void wg_read_succ(succ_indx_t succ)
  {
    printd(2, "wg_read_succ: %d\n", succ);
	if (strat_stack->act != -1)
	{
		instr_pair cur_instrs = { strat_stack->act, succ };
		internal_indx_t cur_int = instrs_to_internal[cur_instrs];
		wg_read_internal(cur_int);
		strat_stack->act = -1;
	}
    printd(2, "wg_read_succ: end\n");
    return;
  }

  strat_frame* push_strat_frame(state_t push_state)
  {
    strat_frame* cur_frame = (strat_frame*) malloc(sizeof(strat_frame));
    if (!cur_frame) {
      printd(2, "push_strat_frame: malloc failed\n");
    }
    cur_frame->state = push_state;
    cur_frame->prev = strat_stack;
	cur_frame->act = -1;
    return cur_frame;
  }

  /* wg_read_call: read a call, invoke the primitive, and push a
   * stack on the strategy state. */
  void wg_read_call(call_indx_t call)
  {
    // Lookup the primitive and post-state for the call.
    printd(2, "%d: wg_read_call %d: begin\n", getpid(), call);
    trans_post post = call_trans[call];
  
    // Invoke the next primitive.
    (post.trans_prim)();

    // Push a new strategy stack on the stack.
    strat_stack = push_strat_frame(post.trans_post_state);
    printd(2, "wg_read_call %d end\n", call);
    return;
  }


  /* wg_read_ret: read a return, invoke the next strategy
   * primitive, and pop the strategy stack. */
  void wg_read_ret(void* callee)
  {
    printd(3, "wg_read_ret: begin on %d\n", callee);
    strat_frame* caller_frame = strat_stack->prev;

    if (strat_calls.count(callee)) {
      printd(3,
			"wg_read_ret: true begin: %d, %d\n",
			strat_stack->state, caller_frame->state);
      fflush(stdout);
      return_pre ret_pre = { strat_stack->state, caller_frame->state };
      trans_post ret_post = return_trans[ret_pre];

      // Invoke the next strategy primitive.
        printd(3,
               "wg_read_ret: ret trans: %x, %d\n",
               ret_post.trans_prim, 
               ret_post.trans_post_state);
        fflush(stdout);
      (ret_post.trans_prim)();
        printd(3, "wg_read_ret: post execute primitive\n");
        fflush(stdout);

      // Update the strategy stack.
      caller_frame->state = ret_post.trans_post_state;

      // Pop the top of the strategy stack.
      free(strat_stack);
      strat_stack = caller_frame;
      printd(3, "wg_read_ret: true end\n");
	  fflush(stdout);
    }

    return;
  }

  // cw*: wrappers for the Capsicum runtime libraries.
  void cw_cap_enter()
  {
    printd(1, "cap_enter: execute\n");
    errno = 0;
    int err_code = 0;
#if EN_CAPENTER
    err_code = cap_enter();
#endif
    if (err_code) {
      fprintf(stderr,
	      "cw_cap_enter: failed to enter capability mode.\n"
	      "cap_enter returned error code %d.\n"
	      "Aborting.\n",
	      errno);
      abort();
    }
    return;
  }

  int is_desc(int fd) {
    cap_rights_t cur_rights;
    errno = 0;
    if (cap_getrights(fd, &cur_rights)) {
      return errno != EBADF;
    }
    else {
      return 1;
    }

    return 1;
  }

    void report_mask(cap_rights_t rights_mask)
    {
        int test_flag = 1;
        for (int i = 0; i < 64; i++) {
            printd(1, "rights mask has flag %x: %d\n",
                    test_flag, rights_mask & test_flag);
            test_flag = test_flag << 1;
        }
        
        return;
    }


  void cw_lc_limitfd(int fd, cap_rights_t rights_mask)
  {
    /* Get the current rights of the capability. */
    printd(1, "lc_limitfd: %d: begin\n", fd);
        fflush(stdout);
	printd(1,
		  "limitfd: mask has READ, FSTAT, FCNTL, SEEK: %d, %d, %d, %d\n",
		rights_mask & CAP_READ,
		rights_mask & CAP_FSTAT,
		rights_mask & CAP_FCNTL,
		rights_mask & CAP_SEEK);
	printd(1,
		   "rights modulo READ, SEEK: %d\n",
		   rights_mask ^ CAP_READ ^ CAP_SEEK);
	// rights_mask |= CAP_FSTAT;
	cap_rights_t cur_rights;
    if (cap_getrights(fd, &cur_rights)) {
      if (errno == EBADF) {
	// fd is not a file descriptor.
	printd(1, "cw_lc_limitfd: %d is not a fd\n", fd);
	return;
      } else {
	// fd is not a capability.
	cur_rights = rights_mask;
      }
    }

    cap_rights_t sub_rights = rights_mask & cur_rights;
    int err_code = 0;
#if EN_LC_LIMITFD
    err_code = lc_limitfd(fd, sub_rights);
#endif
    if (err_code) {
      fprintf(stderr,
	      "cw_lc_limitfd: lc_limitfd failed with error code %d.\n"
	      "Aborting.\n",
	      errno);
      abort();
    }
	
    printd(1, "cw_lc_limitfd: end\n");
    return;
  }

  void cw_noop()
  {
    printd(1, "cw_noop: execute\n");
    return;
  }

  /* blk_read: takes a file descriptor des, buffer buf, and number of
   * bytes to read num_read. Read num_read bytes from des into buf. */
  void blk_read(int des, char* buf, size_t num_read)
  {
    char* ptr = buf;
    while (ptr - buf < num_read) {
      size_t bytes_read = read(des, ptr, num_read - (ptr - buf));
      ptr += bytes_read;
    }

    return;
  }

    // fork_reader: function for reading from a forked child.
    int fork_read_fd;
    void* fork_buf_reader(size_t size) {
        void* buf = malloc(size);
        blk_read(fork_read_fd, (char*) buf, size);
        return buf;
    }

    /* fork_desc_reader: we don't even try to read descriptors over forked
    * children processes. */
    void fork_desc_reader() {
        return;
    }

    /* fork_int_reader: read an integer. */
    int fork_int_reader() {
        int res;
        blk_read(fork_read_fd, (char*) &res, sizeof(int));
        return res;
    }

    size_t fork_size_reader() {
        size_t res;
        blk_read(fork_read_fd, (char*) &res, sizeof(size_t));
        return res;
    }

    void* rpc_buf_reader(size_t sz)
    {
        return host_recv_buf(sandbox, sz);
    }

    /* rpc_desc_reader: construct the virtual descriptor table from the
    * sandbox. */
    void rpc_desc_reader() {
        // Read the number of descriptors.
        int num_descs = host_recv_int(sandbox);
        fprintf(log, "client: num ret descs: %d\n", num_descs);

        /* Read the virtual descriptor table from over the RPC. */
		int* locals;
        int* descs;
        int rcvd =
			host_recv_virt_table(sandbox, num_descs, &locals, &descs);
		if (rcvd != num_descs) {
			fprintf(log,
					"client: expected %d descs, recvd %d\n",
					num_descs, rcvd);
			exit(1);
		}

		fprintf(log, "client: recvd descs:\n");
		for (int i = 0; i < num_descs; i++) {
			fprintf(log,
					"client: index: %d: local %d: desc: %d\n",
					i, locals[i], descs[i]);
		}
		fflush(log);

        // Set the virtual descriptor table.
        init_descs(locals, descs, num_descs);
        return;
    }

    // Reads an unsigned integer over an RPC channel.
    int rpc_int_reader()
    {
        return host_recv_int(sandbox);
    }


    // rpc_size_reader: reads a size over an RPC channel.
    size_t rpc_size_reader()
    {
        return host_recv_size(sandbox);
    }

    typedef void* (buf_reader)(size_t);
    typedef void desc_reader();
    typedef int int_reader();
    typedef size_t size_reader();

  /* read_work: read from the server:
   *
   * -the virtual descriptor table
   *
   * -the return value
   * 
   * -the strategy state
   * 
   * Store the strategy state on the strategy stack.
   */
  iovec*
  read_work(
    buf_reader buf_rdr,
    desc_reader desc_rdr,
    int_reader int_rdr,
    size_reader sz_rdr)
  {
    // Desc reader: read the descriptor table.
    fprintf(log, "client: pre read descs\n");
    desc_rdr();

    /* Read the size of the result from the worker. */
    printd(1, "client: pre read return size\n");
    size_t res_sz = sz_rdr();
    printd(1, "client: return size: %ld\n", res_sz);
    fflush(stdout);

    /* Allocate a buffer big enough to hold the result, then read
     * data into it. */
    printd(1, "client: pre read return value\n");
    fflush(stdout);
    void* res_buf = buf_rdr(res_sz);

    /* Construct an iovec that holds the result. */
    iovec* work_res = (iovec*) malloc(sizeof(iovec));
    work_res->iov_base = res_buf;
    work_res->iov_len = res_sz;

    /* Allocate a strategy frame, read the strategy state from the
     * child, and store the state in the frame. */
	printd(1, "client: pre read strategy state\n");
    state_t child_state = int_rdr();
    strat_stack = push_strat_frame(child_state);
    printd(1, "child strategy state: %d\n", child_state);
    return work_res;
  }

  /* cw_fork_setup: takes as input:
   *
   * -work: a work function that is to be executed after a fork.
   *
   * -args: a vector of arguments
   * 
   * -num_args: the number of arguments. Not used, only declare to be
   *  compatible with RPC setup function.
   *
   * Returns:
   *
   * -a iovec holding the return value of the work function.
   */
  iovec* cw_fork_setup(call_indx_t worker, iovec* args, int num_args)
  {
    /* Create a pipe for two-way communication between parent and
     * child.
     */
    printd(0, "fork: begin: %d\n", getpid());

    trans_func = void_ptr_id;
    int pipe_ends[2];
    int pipe_status = pipe(pipe_ends);
    int read_end = pipe_ends[0];
    int write_end = pipe_ends[1];

    /* fork_res: stores the result of the fork. */
    iovec* fork_res;
    
    if (pipe_status) {
      fprintf(stderr, "cw_fork: failed to create pipe.\nAborting.\n");
      abort();
    }
    else {
      pid_t pid = fork();
      printd(1, "cw_fork_setup: post fork: %d\n", getpid());

      if (pid == -1) {
        // The fork failed.
        fprintf(stderr, "cw_fork: failed to fork.\nAborting.\n");
        abort();
      }
      else if (pid == 0) {
        /* We are the child. First, close half the pipe so that we can
         * only write. */
        printd(1, "fork: begin child %d\n", getpid());
        close(read_end);
	
		// Do the work and it over the pipe.
		fork_write_fd = write_end;
			work_and_write(
				-1, // bogus desc that should never get written to.
				worker,
				args,
				fork_buf_writer,
				fork_desc_writer,
				fork_int_writer,
				fork_size_writer);
	
        close(write_end);
        printd(1, "fork: end child %d\n", getpid());
        exit(0);
      }
      else {
        /* We are the parent. First, close the pipe so that we can
         * only read. */
        printd(1, "parent %d\n", getpid());
        close(write_end);

	// Read information from the child worker.
	fork_read_fd = read_end;
	fork_res = 
            read_work(
                fork_buf_reader,
                fork_desc_reader,
                fork_int_reader,
                fork_size_reader);
        close(read_end);
	printd(1, "parent-side end\n");
      }
    }

    printd(0, "fork: end\n");
    return fork_res;
  }

  iovec*
  cw_rpc_setup(call_indx_t worker, iovec* args, int num_args)
  {
	fprintf(log, "cw_rpc_setup: %d\n", worker);
	fprintf(log, "cw_rpc_setup: arg 0: %s\n", (char*) args->iov_base);
	fflush(log);
    size_t* len_p;

    // Build buffer of virtual file descriptors, array of file descriptors.
	int sock;
	lch_getsock(sandbox, &sock);
    int* fds;
    int num_fds = collect_descs(sock, &fds);

    /* Make an RPC call passing the number of file descriptors. */
    fprintf(log, "client: pre RPC\n");
    fflush(log);
	int num_fds_rc = rpc_int(sandbox, worker, num_fds);
	if (num_fds_rc < 0) {
		fprintf(log, "client: failed to send number of fds\n");
		abort();
	}

    // Send the virtual descriptor table.
    fprintf(log, "client: pre send virt table: %d descs\n", num_fds);
    fflush(log);
	for (int i = 0; i < num_fds; i++) {
		fprintf(log, "client: desc %d: %d\n", i, fds[i]);
	}

    int vt_rc = host_send_virt_table(sandbox, fds, num_fds);
	if (vt_rc) {
		fprintf(log, "client: failed to send virt table\n");
		abort();
	}

	free(fds);

    // Send a vector holding the number of arguments.
    fprintf(log, "client: pre send number arguments: %d\n", num_args);
    fflush(log);
    int rc = host_send_int(sandbox, num_args);

	// Check if the client sent the entire number successfully.
	if (rc) {
		fprintf(log, "client: failed to send num args\n");
		abort();
	}

    fprintf(log, "client: pre send arguments\n");
	fflush(log);

    // Build an array of the number of descriptors.
    // Send each argument.
    for (int arg_index = 0; arg_index < num_args; arg_index++) {
        struct iovec cur_arg = args[arg_index];
		printd(1, "client: arg len: %d\n", cur_arg.iov_len);
		fflush(stdout);
        host_send_size(sandbox, cur_arg.iov_len);
		printd(1, "client: arg buf: %x\n", cur_arg.iov_base);
		fflush(stdout);
        host_send_buf(sandbox, cur_arg.iov_base, cur_arg.iov_len);
    }

    // Read return value from sandbox.
	fflush(stdout);
    fprintf(log, "client: pre read work\n");
	fflush(log);
    return
        read_work(
            rpc_buf_reader,
            rpc_desc_reader,
            rpc_int_reader,
            rpc_size_reader);
  }

  void cw_desc(int c, int d) {
    return;
  }

  void cw_act(int i) {
	fprintf(log, "cw action: %d\n", i);
    return;
  }

  /* cw_fork: sets the callee-translation function. */
  void cw_fork()
  {
    printd(1, "cw_fork: begin\n");
#if EN_FORK
    setup_func = cw_fork_setup;
    trans_func = repl_marshaller;
#endif
    printd(1, "cw_fork: end\n");
    return;
  }

  /* cw_rpc: prepare to execute the next call via RPC.
   */
  void cw_rpc()
  {
    printd(1, "cw_rpc: execute\n");
#if EN_RPC
    setup_func = cw_rpc_setup;
    trans_func = repl_marshaller;
#endif
    printd(1, "cw_rpc: end\n");
    return;
  }

  void* i8_2A__to_voidp(char** strp) {
        return (void*) *strp;
  }

  char* voidpp_to_i8_2A_(void* p) {
        return (char*) p;
  }

  ssize_t i8_2A__size(char* p) {
		int len = strlen(p) + 1;
        return len;
  }

  /* cw_extract_fpp: extract a descriptor from a FILE** into a
   * descriptor pointer. */
  void cw_extract_fpp(FILE* fp, int* dsc)
  {
    printd(1, "cw_extract_fpp: pre set\n");
    *dsc = fileno(fp);
    printd(1, "cw_extract_fpp: post set\n");
    return;
  }

  // cw_extract_fd: extract a descriptor into a descriptor pointer.
  void store_fd(int fd, int* dsc)
  {
	printd(1, "store_fd: %d\n", fd);
    *dsc = fd;
    return;
  }

  /* cw_extract_pcapp: extract a descriptor from a pcap_t into a
   * desctiptor pointer. */
  void cw_extract_pcapp(pcap_t* cap_p, int* dsc)
  {
    /* commented for unit testing.
    FILE* pcap_f = pcap_file(cap_p);
    if (pcap_f) {
      *dsc = fileno(pcap_f);
    }
    else {
      *dsc = pcap_fileno(cap_p);
    }
    */

    return;
  }

  /* wg_dbg: general-purpose debugging function. */
  void wg_dbg(int code)
  {
    printd(2, "wg_dbg: %d\n", code);
    return;
  }

  void wg_dbg_ptr(char* ptr)
  {
    printd(2, "wg_dbg_ptr: %x\n", ptr);
    return;
  }

        /* (hypothetical) alternate entry point of the instrumented 
         * program. */
  int cap_main(int argc, char* argv[]) {
    printd(1, "cap_main: enter\n");
    return 0;
  }
}
