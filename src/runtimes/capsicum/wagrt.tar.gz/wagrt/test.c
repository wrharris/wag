#include <fcntl.h>
#include <stdio.h>

#include <sys/capability.h>
#include <sys/errno.h>
#include <sys/socket.h>

#include <libcapsicum.h>

int main() {
	cap_enter();
	int s = socket(AF_INET, SOCK_STREAM, 0);
	int c = cap_new(s, CAP_MASK_VALID);
	cap_rights_t rs;
	rs = 0;
	cap_getrights(c, &rs);
	printf("socket %d, cap %d, rights: %ld, has CONNECT: %ld\n",
		   s, c, rs, rs & CAP_CONNECT);

	cap_enter();
	s = 0;
	s = socket(AF_INET, SOCK_STREAM, 0);
	c = cap_new(s, CAP_MASK_VALID);
	rs = 0;
	cap_getrights(c, &rs);
	printf("socket %d, cap %d, rights: %ld, has CONNECT: %ld\n",
		   s, c, rs, rs & CAP_CONNECT);
	return 0;
}
