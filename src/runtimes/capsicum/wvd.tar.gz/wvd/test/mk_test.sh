#!/usr/local/bin/bash

g++ \
    -I/home/capsicum/wvd/wagrt/ \
    -L/usr/lib \
    -lcapsicum \
    /home/capsicum/wvd/wagrt/autolibcapsicum.o \
    test_client.c \
    -o test_client

g++ \
    -I/home/capsicum/wvd/wagrt/ \
    -L/usr/lib \
    -lcapsicum \
    /home/capsicum/wvd/wagrt/autolibcapsicum.o \
    test_med.c \
    -o test_med

g++ \
    -I/home/capsicum/wvd/wagrt/ \
    -L/usr/lib \
    -lcapsicum \
    /home/capsicum/wvd/wagrt/autolibcapsicum.o \
    test_server.c \
    -o test_server
