#include <fcntl.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/capability.h>
#include <sys/errno.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <sys/uio.h>
#include <libcapsicum.h>

#include <autolibcapsicum.h>

extern char** environ;

int main(int argc, char* argv[])
{
        // If we're the server:
    printf("argc: %d, argv[0]: %s\n", argc, argv[0]);
    struct lc_host* host;
    lcs_get(&host);
    int arg = sb_recv_int(host);
    // printf("server: arg: %d\n", arg);
    sb_send_int(host, arg);
    return 0;
}


