#include <fcntl.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/capability.h>
#include <sys/errno.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <sys/uio.h>
#include <libcapsicum.h>

#include <autolibcapsicum.h>

extern char** environ;

extern struct iovec* cw_rpc_setup(int, struct iovec*, int);
extern void wg_init_strat(char*);

int main(int argc, char* argv[])
{
    struct lc_host* host;
    lcs_get(&host);

    while (1)
    {
        u_int32_t op;
        u_int32_t seq;
        printf("pre recv rpc\n");
        fflush(stdout);
        int arg = recv_int_rpc(host, &op, &seq);
            unblock_host(host, op, seq);
        pid_t p = fork();
        if (!p)
        {
            printf("pre recv arg 2\n");
            fflush(stdout);
            int arg2 = sb_recv_int(host);
            printf("args: %d, %d\n", arg, arg2);
            fflush(stdout);
            sb_send_int(host, arg + arg2);
            exit(0);
        }
        else 
        {
            int status;
            waitpid(p, &status, 0);
        }

    }

    return 0;
}

