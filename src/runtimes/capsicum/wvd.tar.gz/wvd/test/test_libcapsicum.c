#include <fcntl.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/capability.h>
#include <sys/errno.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <sys/uio.h>
#include <libcapsicum.h>

#include <autolibcapsicum.h>

extern char** environ;

extern struct iovec* cw_rpc_setup(int, struct iovec*, int);
extern void wg_init_strat(char*);

int main(int argc, char* argv[])
{
    // Initialize the RPC servers.
    if (ld_insandbox())
    {
        // If we're the server:
        printf("argc: %d\n", argc);
        if (argc > 1)
        {
            struct lc_host* host;
            lcs_get(&host);
            int arg = sb_recv_int(host);
            printf("server: arg: %d\n", arg);
        }
        else
        {
            char* const sb_argv[3] = { "./a.out", "foo", NULL };
            printf("pre start first sandbox\n");
            fflush(stdout);
            struct lc_sandbox* sb = basic_start_sb("./a.out", sb_argv);
            printf("pre send first int\n");
            fflush(stdout);
            host_send_int(sb, 41);
            sleep(1);
            char* const sb_argv2[3] = { "./a.out", "foo", NULL };
            printf("pre start second sandbox\n");
            fflush(stdout);
            sb = basic_start_sb("./a.out", sb_argv2);
            printf("pre send second int\n");
            fflush(stdout);
            // host_send_int(sb, 42);
            sleep(1);
            lch_stop(sb);
        }
    }
    else
    {
        // Not in sandbox.
        char* const sb_argv[2] = { "./a.out", NULL };
        printf("non-sb: pre start sandbox\n");
        fflush(stdout);
        struct lc_sandbox* sb = basic_start_sb("./a.out", sb_argv);
        sleep(5);
    }

    return 0;
}

/*
int cap_main(int argc, char* argv[]) {
	printf("cap_main: in Capsicum sandbox: %d\n", ld_insandbox());
	return 0;
}
*/
