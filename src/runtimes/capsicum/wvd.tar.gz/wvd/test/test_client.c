#include <fcntl.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/capability.h>
#include <sys/errno.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <sys/uio.h>
#include <libcapsicum.h>

#include <autolibcapsicum.h>

extern char** environ;

extern struct iovec* cw_rpc_setup(int, struct iovec*, int);
extern void wg_init_strat(char*);

int main(int argc, char* argv[])
{
    // Not in sandbox.
    char* const sb_argv[2] = { "./test_med", NULL };
    printf("non-sb: pre start sandbox\n");
    fflush(stdout);
    struct lc_sandbox* sb = basic_start_sb("./test_med", sb_argv);
    printf("non-sb: pre rpc\n");
    fflush(stdout);
    rpc_int(sb, 0, 43);
    printf("non-sb: pre send arg 2\n");
    fflush(stdout);
    host_send_int(sb, 42);
    printf("non-sb: pre recv result\n");
    fflush(stdout);
    int ret2 = host_recv_int(sb);
    printf("ret: %d\n", ret2);
    return 0;
}

/*
int cap_main(int argc, char* argv[]) {
	printf("cap_main: in Capsicum sandbox: %d\n", ld_insandbox());
	return 0;
}
*/
