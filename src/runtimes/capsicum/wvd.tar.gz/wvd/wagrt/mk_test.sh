#!/usr/local/bin/bash
g++ -L/usr/lib/ -lcapsicum weaver_runtime.cpp
