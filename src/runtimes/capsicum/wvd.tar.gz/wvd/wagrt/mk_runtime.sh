#!/usr/local/bin/bash

# Compile the autolibcap library.
g++ -c autolibcapsicum.c

# Compile the mediator binary.
# g++ -L/usr/lib -lcapsicum autolibcapsicum.o mediator.c -o mediator

# Build the runtime library.
g++ \
    -rdynamic \
    -c \
    weaver_runtime.cpp
