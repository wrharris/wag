// Include C++ STL map.
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <string>

// Include C libs.
#include <pcap.h>
#include <fcntl.h>
#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <sys/errno.h>
#include <sys/uio.h>
#include <sys/wait.h>
#include <unistd.h>

// Include Capsicum.
#include <sys/capability.h>
#include <libcapsicum.h>

// Include library for automatic marshalling into libcapsicum.
#include "autolibcapsicum.h"

// state: the state of the weaver
typedef int state_t;

// prog_comm_indx_t: an index of a program command
typedef int action_indx_t;

/* prog_block_indx_t: an index of a successor instruction that signals a
 * completed internal action. */
typedef int succ_indx_t;

// internal_indx_t: an index of an internal action.
typedef int internal_indx_t;

// prog_call_indx_t: an index of a call.
typedef int call_indx_t;

// prim_ptr: a pointer to a host primitive to execute
typedef void(*prim_ptr)();

/* Support RPC. First, a map from each work function to its
 * unmarshaller. */
typedef void* marshaller_ptr;

typedef iovec* (*unmarshaller_ptr)(iovec*);

/* Each of the following transition matrices is a stub that allows the
 * library to compile. Each is redeclared as a multidemensional array
 * and initialized by the policy-weaver generator.
 */

// Parallel arrays relating LLVM instructions to internal actions.
extern action_indx_t int_acts[];

extern succ_indx_t int_succs[];

// Parallel arrays representing the internal transition function.
extern state_t int_trans_pres[];

extern internal_indx_t int_trans_acts[];

extern prim_ptr int_trans_prims[];

extern state_t int_trans_posts[];

// Parallel arrays representing the call transition function.
extern prim_ptr call_trans_prims[];

extern state_t call_trans_posts[];

extern void* strat_calls_arr[];

// Parallel arrays representing the return transition function.
extern state_t ret_trans_pres[];

extern state_t ret_trans_stacks[];

extern prim_ptr ret_trans_prims[];

extern state_t ret_trans_posts[];

// Parallel arrays representing RPC data structures.
extern marshaller_ptr marsh_arr[];

extern unmarshaller_ptr unmarsh_arr[];


// Number of strategy objects.
extern int num_internals;
extern int num_calls;
extern int num_int_trans;
extern int num_ret_trans;

using namespace std;

// instr_pair: a pair of instructions.
typedef
struct instr_pair_s
{
  action_indx_t act;
  succ_indx_t succ;
} instr_pair;

string int_to_string(int i)
{
  return static_cast<ostringstream*>(&(ostringstream() << i))->str();
}

// mediator_path: location of the mediator executable.
const char* mediator_path = "/home/capsicum/wvd/wagrt/mediator";

int dbg_threshold = 1;

// printd: debug printer.
void printd(int prio, string str) {
  if (prio <= dbg_threshold) {
    printf(str.c_str());
  }

  return;
}

int compare_ints(int a, int b)
{
  if (a < b) {
    return -1;
  }
  else if (a > b) {
    return 1;
  }
  else {
    return 0;
  }
}
               
bool operator<(const instr_pair& a, const instr_pair& b)
{
  int act_cmp = compare_ints(a.act, b.act);
  if (act_cmp != 0) {
    return act_cmp < 0;
  }
  else {
    return compare_ints(a.succ, b.succ) < 0;
  }
}

// virt_descs: a map from each virtual descriptor to its actual descriptor.
map<int, int> virt_descs;

int resolve_virt(int virt) {
        return virt_descs[virt];
}

FILE* virt_fdopen(int fd, const char* mode) {
        return fdopen(resolve_virt(fd), mode);
}

// internal_pre: prefix of an internal transition.
typedef
struct internal_pre_s
{
  state_t pre_state;
  internal_indx_t internal;
} internal_pre;

bool operator<(const internal_pre& a, const internal_pre& b)
{
  int pre_cmp = compare_ints(a.pre_state, b.pre_state);
  if (pre_cmp != 0) {
    return pre_cmp < 0;
  }
  else {
    return compare_ints(a.internal, b.internal) < 0;
  }
}

// trans_post: effect of a transition.
typedef
struct trans_post_s
{
  prim_ptr trans_prim;
  state_t trans_post_state;
} trans_post;

// return_pre: prefix of a return transition.
typedef
struct return_pre_s
{
  state_t pre;
  state_t stack;
} return_pre;

bool operator<(const return_pre& a, const return_pre& b)
{
  int pre_cmp = compare_ints(a.pre, b.pre);
  if (pre_cmp != 0) {
    return pre_cmp < 0;
  }
  else {
    return compare_ints(a.stack, b.stack) < 0;
  }
}

// strat_frame: an "activation record" of the strategy.
typedef
struct strat_frame_h
{
  state_t state;
  struct strat_frame_h* prev;
} strat_frame;

iovec* (*setup_func)(call_indx_t, iovec*, int);

/* instrs_to_internal: a map from pairs of instructions to internal
 * actions. */
using namespace std;
map<instr_pair, internal_indx_t> instrs_to_internal;

/* internal_trans: map representation of the internal transition
 * function. */
map<internal_pre, trans_post> internal_trans;

// call_trans: map representation of the call transition function.
map<call_indx_t, trans_post> call_trans;

/* strat_calls: the calls that are relevant to the strategy. */
set<void*> strat_calls;

// return_trans: map representation of the return transition function.
map<return_pre, trans_post> return_trans;

/* strat_stack: the stack of the strategy. */
strat_frame* strat_stack = NULL;

/* instr_indx: index of the open action index. */
action_indx_t action_indx;

map<void*, marshaller_ptr> worker_marshaller;

map<call_indx_t, unmarshaller_ptr> worker_unmarshaller;

/* trans_func: takes a pointer to a work function and translates to
 * a pointer to a function that potentially traps into a fork. */
void* (*trans_func)(void*);

extern "C" {

  void print_virt_descs() {
    for (map<int, int>::iterator vd_it = virt_descs.begin();
     vd_it != virt_descs.end();
     vd_it++) {
        printf("virt: %d, desc: %d\n",
                vd_it->first, vd_it->second);
    }
    return;
  }

    int virt_close(int virt) {
        int err = close(resolve_virt(virt));
        virt_descs.erase(virt);
        return err;
    }

 // virt_open: wrapper of open that allocates a virtual descriptor.
int virt_open(char* path, int mode) {
    // Find the lowest free virtual descriptor.
	int open_virt = 0;
	int key_found = 0;
	while (!key_found) {
		if (virt_descs.count(open_virt)) {
			open_virt++;
		}
		else {
			key_found = 1;
		}
	}

    // Open the descriptor.
    int fd = open(path, mode);

    // Bind the virtual descriptor to the open descriptor.
        printf("virt_open: %s, %d, %d, %d\n", path, mode, open_virt, fd);
    virt_descs.insert(pair<int, int>(open_virt, fd));

    // Return the virtual descriptor.
    return open_virt;
}

int virt_read(int fd, void* buf, size_t num_bytes) {
        return read(resolve_virt(fd), buf, num_bytes);
}

int virt_write(int fd, void* buf, size_t num_bytes) {
        return write(resolve_virt(fd), buf, num_bytes);
}

 /* void_ptr_id: the identity function over void*. */
  void* void_ptr_id(void* x)
  {
    printd(1, "void_ptr_id: execute\n");
    return x;
  }

  /* repl_marshaller: replace a function pointer with its marshaller.
   */
  void* repl_marshaller(void* x)
  {
    printd(1, "repl_marshaller: begin\n");
    void* res;
    if (strat_calls.count(x) == 0) {
      res = x;
    }
    else {
      res = worker_marshaller[x];
    }

    return res;
  }

  /* serialize_virt_descs: serializes the virtual descriptor table into
   * an array of virtual descriptors and an array of descriptors. */
  int serialize_virt_descs(int** virts, int** descs) {
        int num_descs = virt_descs.size();
        *virts = (int*) malloc(sizeof(int) * num_descs);
        *descs = (int*) malloc(sizeof(int) * num_descs);
        int desc_index = 0;
        for (map<int, int>::iterator tab_it = virt_descs.begin();
             tab_it != virt_descs.end();
             tab_it++) {
                (*virts)[desc_index] = tab_it->first;
                (*descs)[desc_index] = tab_it->second;
                desc_index++;
        }

        return num_descs;
  }

  /* set_virt_descs: takes arrays of virtual descriptors and descriptors.
   * populates the virtual descriptor table. */
  void set_virt_descs(int* virts, int* fds, int num_descs) {
        virt_descs.clear();
        for (int desc_index = 0; desc_index < num_descs; desc_index++) {
          int desc = fds[desc_index];
          int virt = virts[desc_index];
          virt_descs.insert(pair<int, int>(virt, desc));
        }

        return;
  }

    struct lc_sandbox* sandbox;

    // fork_writer: the writer function for the fork.
    int fork_write_fd;
    void fork_buf_writer(void* buf, size_t len) {
        write(fork_write_fd, buf, len);
        return;
    }

    /* fork_desc_writer: function for writing back descriptors over forks.
     * Doesn't actually try to write descriptors over a fork. */
    void fork_desc_writer() {
        return;
    }

    void fork_int_writer(int i)
    {
        write(fork_write_fd, &i, sizeof(int));
        return;
    }

    void fork_size_writer(size_t sz)
    {
        write(fork_write_fd, &sz, sizeof(size_t));
        return;
    }

    typedef void buf_writer(void*, size_t);
    typedef void desc_writer();
    typedef void int_writer(int);
    typedef void size_writer(size_t);

    // rpc_buf_writer: writes a buffer over an RPC.
    void rpc_buf_writer(void* buf, size_t len) {
        lc_host* host;
        int get_status = lcs_get(&host);

        // Get the host.
        if (get_status) {
          // Failed to get host.
          fprintf(stderr, "sandbox: failed to get host. Aborting.\n");
          abort();
        }

        sb_send_buf(host, buf, len);
        return;
    }

    /* rpc_desc_writer: function for writing back descriptors over RPCs.
    * Serializes the descriptor table. */
    void rpc_desc_writer() {
        int* virts;
        int* descs;
        int num_descs = serialize_virt_descs(&virts, &descs);

        lc_host* host;
        int get_status = lcs_get(&host);

        if (get_status) {
            // Failed to get host.
            fprintf(stderr, "sandbox: failed to get host. Aborting.\n");
            abort();
        }

        // Send number of descriptors.
        sb_send_int(host, num_descs);

        // Send the virtual descriptor table.
        sb_send_virt_table(host, virts, descs, num_descs);
        return;
    }

    void rpc_int_writer(int i)
    {
        lc_host* host;
        int get_status = lcs_get(&host);
        if (get_status) {
            // Failed to get host.
            fprintf(stderr, "sandbox: failed to get host. Aborting.\n");
            abort();
        }

        sb_send_int(host, i);
        return;
    }

    void rpc_size_writer(size_t sz)
    {
        lc_host* host;
        int get_status = lcs_get(&host);
        if (get_status) {
            // Failed to get host.
            fprintf(stderr, "sandbox: failed to get host. Aborting.\n");
            abort();
        }

        sb_send_size(host, sz);
        return;
    }

    /* work_and_write: do the work and write it out. */
    void work_and_write(
        call_indx_t worker,
        iovec* args,
        buf_writer buf_writr,
        desc_writer desc_writr,
        int_writer int_writr,
        size_writer size_writr)
    {
        /* Lookup the unmarshaller for the work function. */
        unmarshaller_ptr unmarsh = worker_unmarshaller[worker];

        /* Call the unmarshaller to do the work. */
        iovec* res = (*unmarsh)(args);

        // Write the descriptor table back to the parent.
        desc_writr();

        /* Write the size of the return value. */
        size_writr(res->iov_len);

        /* Write the return value. */
        buf_writr(res->iov_base, res->iov_len);

        /* Write the strategy state back to the parent. */
        int_writr(strat_stack->state);
        return;
  }

  /* serve_reqs: poll, servicing requests. */
  void serve_reqs() {
    // Fetch the host object.
    lc_host* host;
    int get_status = lcs_get(&host);
    if (get_status) {
      // Failed to get host.
      fprintf(stderr, "sandbox: failed to get host. Aborting.\n");
      abort();
    }

    // Recv an RPC request.
    u_int32_t op;
    u_int32_t seq_op;
    int num_descs = recv_int_rpc(host, &op, &seq_op);

    // Unblock the parent.
    unblock_host(host, op, seq_op);

    // Read the file descriptors from the parent.
    int* virts = (int*) malloc(num_descs * sizeof(int));
    int* fds = (int*) malloc(num_descs * sizeof(int));
    sb_recv_virt_table(host, num_descs, &virts, &fds);
    

    /* Populate the table of virtual descriptors. */
    set_virt_descs(virts, fds, num_descs);

    // Read the number of arguments.
    int num_args = sb_recv_int(host);
    struct iovec* args =
        (struct iovec*) malloc(sizeof(struct iovec) * num_args);
    for (int arg_indx = 0; arg_indx < num_args; arg_indx++) {
        size_t arg_size = sb_recv_size(host);
        void* arg_buf = sb_recv_buf(host, arg_size);
        args[arg_indx].iov_base = arg_buf;
        args[arg_indx].iov_len = arg_size;
    }

    // Do the work and write it back to the RPC caller.
    work_and_write(
        op,
        args,
        rpc_buf_writer,
        rpc_desc_writer,
        rpc_int_writer,
        rpc_size_writer);

    return;
  }

  /* wg_init_strat: populate the transition maps with entries from the
   * array generated by LLVM.
   */
  void wg_init_strat(char* bin_name) {
    // Populate the instructions-to-internals function.
    printd(1, "wg_init: begin\n");

        /* Populate the virtual descriptor table with entries for the
         * standard file descriptors. */
        virt_descs.insert(pair<int, int>(0, 0));
        virt_descs.insert(pair<int, int>(1, 1));
        virt_descs.insert(pair<int, int>(2, 2));

    instrs_to_internal = map<instr_pair, internal_indx_t>();
    for (int i = 0; i < num_internals; i++) {
      instr_pair int_instrs = { int_acts[i], int_succs[i] };
      instrs_to_internal.insert(
        pair<instr_pair, internal_indx_t>(int_instrs,
                                                                  i));
    }

    // Populate the internal transition function.
    internal_trans = map<internal_pre, trans_post>();
    for (int i = 0; i < num_int_trans; i++) {
      internal_pre cur_pre = { int_trans_pres[i], int_trans_acts[i] };
      trans_post cur_post = { int_trans_prims[i], int_trans_posts[i] };
      internal_trans.insert(pair<internal_pre, trans_post>(cur_pre,
                                                           cur_post));
    }

    // Populate the call transition function.
    strat_calls = set<void*>();
    call_trans = map<call_indx_t, trans_post>();
    for (int i = 0; i < num_calls; i++) {
      trans_post cur_post = { call_trans_prims[i], call_trans_posts[i] };
      strat_calls.insert(strat_calls_arr[i]);
      strat_calls.insert(marsh_arr[i]);
      call_trans.insert(pair<call_indx_t, trans_post>(i, cur_post));
    }

    strat_calls.erase(0);

    // Populate the return transition function.
    return_trans = map<return_pre, trans_post>();
    for (int i = 0; i < num_ret_trans; i++) {
      return_pre cur_pre = { ret_trans_pres[i], ret_trans_stacks[i] };
      trans_post cur_post = { ret_trans_prims[i], ret_trans_posts[i] };
      return_trans.insert(pair<return_pre, trans_post>(cur_pre, cur_post));
    }

    // Populate maps used by fork and RPC.
    worker_marshaller = map<void*, marshaller_ptr>();
    worker_unmarshaller = map<int, unmarshaller_ptr>();
    for (int i = 0; i < num_calls; i++) {
      worker_marshaller.insert(pair<void*, marshaller_ptr>
                               (strat_calls_arr[i], marsh_arr[i]));
        printf("unmarsh array entry: %d, %x\n", i, unmarsh_arr[i]);
      worker_unmarshaller.insert(pair<int, unmarshaller_ptr>
                                 (i, unmarsh_arr[i]));
    }

    trans_func = void_ptr_id;

    if (ld_insandbox()) {
      // This process is in a sandbox. Service RPC requests.
      printd(1, "in sandbox\n");
      serve_reqs();
      exit(0);
    }
    else {
      // This process is not a sandbox. Launch a sandbox.
      printd(1, "not in sandbox\n");
      char* const sandbox_argv[2] = { bin_name, NULL };
      sandbox = basic_start_sb(mediator_path, sandbox_argv);
    }

    printd(1, "wg_init_strat: end\n");
    return;
  }

  void wg_read_internal(internal_indx_t int_ind)
  {
    // Lookup the post-state and primitive.
    printd(2, "wg_read_internal: stack state: " 
	   + int_to_string(strat_stack->state) + "\n");
    printd(2, "wg_read_internal " + int_to_string(int_ind) + ": begin\n");
    internal_pre int_pre = { strat_stack->state, int_ind };
    trans_post int_post = internal_trans[int_pre];

    // Invoke the next primitive.
    (*(int_post.trans_prim))();

    // Update the strategy state.
    strat_stack->state = int_post.trans_post_state;
    printd(2, "wg_read_internal: end\n");
    return;
  }

  /* wg_read_action: read a program action. */
  void wg_read_action(action_indx_t cur_action)
  {
    action_indx = cur_action;
    printd(1, "wg_read_action: end\n");
    return;
  }

  /* wg_read_succ: read the successor that closes an action. */
  void wg_read_succ(succ_indx_t succ)
  {
    instr_pair cur_instrs = { action_indx, succ };
    internal_indx_t cur_int = instrs_to_internal[cur_instrs];
    wg_read_internal(cur_int);
    action_indx = -1;
    printd(2, "wg_read_succ: end\n");
    return;
  }

  strat_frame* push_strat_frame(state_t push_state)
  {
    strat_frame* cur_frame = (strat_frame*) malloc(sizeof(strat_frame));
    if (!cur_frame) {
      printf("push_strat_frame: malloc failed\n");
    }
    cur_frame->state = push_state;
    cur_frame->prev = strat_stack;
    return cur_frame;
  }

  /* wg_read_call: read a call, invoke the primitive, and push a
   * stack on the strategy state. */
  void wg_read_call(call_indx_t call)
  {
    // Lookup the primitive and post-state for the call.
    printf("wg_read_call: begin %d\n", call);
    trans_post post = call_trans[call];
  
    // Invoke the next primitive.
    (post.trans_prim)();

    // Push a new strategy stack on the stack.
    strat_stack = push_strat_frame(post.trans_post_state);
    printf("wg_read_call: end %d\n", call);
    return;
  }


  /* wg_read_ret: read a return, invoke the next strategy
   * primitive, and pop the strategy stack. */
  void wg_read_ret(void* callee)
  {
    // printf("wg_read_ret: begin on %d\n", callee);
    strat_frame* caller_frame = strat_stack->prev;

    if (strat_calls.count(callee)) {
      printd(1, "wg_read_ret: true begin\n");
      return_pre ret_pre = { strat_stack->state, caller_frame->state };
      trans_post ret_post = return_trans[ret_pre];

      // Invoke the next strategy primitive.
      (ret_post.trans_prim)();

      // Update the strategy stack.
      caller_frame->state = ret_post.trans_post_state;

      // Pop the top of the strategy stack.
      free(strat_stack);
      strat_stack = caller_frame;
      printd(1, "wg_read_ret: true end\n");
    }

    printd(1, "wg_read_ret: end\n");
    return;
  }

  // cw*: wrappers for the Capsicum runtime libraries.
  void cw_cap_enter()
  {
    printd(0, "cap_enter: execute\n");
    errno = 0;
    // wrharris: dbg
    int err_code = 0;
    err_code = cap_enter();
    if (err_code) {
      fprintf(stderr,
	      "cw_cap_enter: failed to enter capability mode.\n"
	      "cap_enter returned error code %d.\n"
	      "Aborting.\n",
	      errno);
      abort();
    }
    return;
  }

  int is_desc(int fd) {
    cap_rights_t cur_rights;
    errno = 0;
    if (cap_getrights(fd, &cur_rights)) {
      return errno != EBADF;
    }
    else {
      return 1;
    }

    return 1;
  }

    void report_mask(cap_rights_t rights_mask)
    {
        int test_flag = 1;
        for (int i = 0; i < 64; i++) {
            printf("rights mask has flag %x: %d\n",
                    test_flag, rights_mask & test_flag);
            test_flag = test_flag << 1;
        }
        
        return;
    }


  void cw_lc_limitfd(int virt, cap_rights_t rights_mask)
  {
    /* Get the current rights of the capability. */
    int fd = resolve_virt(virt);
    printf("lc_limitfd: %d: begin\n", fd);
        fflush(stdout);
    cap_rights_t cur_rights;
    if (cap_getrights(fd, &cur_rights)) {
      if (errno == EBADF) {
	// fd is not a file descriptor.
	printf("cw_lc_limitfd: %d is not a fd\n", fd);
	return;
      } else {
	// fd is not a capability.
	cur_rights = rights_mask;
      }
    }

    cap_rights_t sub_rights = rights_mask & cur_rights;
    printf("sub rights has CAP_READ: %d, CAP_SEEK: %d\n",
	sub_rights & CAP_READ, sub_rights & CAP_SEEK);
    printf("sub rights is CAP_READ: %d\n", sub_rights == CAP_READ);
    int err_code = lc_limitfd(fd, sub_rights);
    if (err_code) {
      fprintf(stderr,
	      "cw_lc_limitfd: lc_limitfd failed with error code %d.\n"
	      "Aborting.\n",
	      errno);
      abort();
    }
	
    printd(1, "cw_lc_limitfd: end\n");
    return;
  }

  void cw_noop()
  {
    printd(1, "cw_noop: execute\n");
    return;
  }

  /* blk_read: takes a file descriptor des, buffer buf, and number of
   * bytes to read num_read. Read num_read bytes from des into buf. */
  void blk_read(int des, char* buf, size_t num_read)
  {
    char* ptr = buf;
    while (ptr - buf < num_read) {
      size_t bytes_read = read(des, ptr, num_read - (ptr - buf));
      ptr += bytes_read;
    }

    return;
  }

    // fork_reader: function for reading from a forked child.
    int fork_read_fd;
    void* fork_buf_reader(size_t size) {
        void* buf = malloc(size);
        blk_read(fork_read_fd, (char*) buf, size);
        return buf;
    }

    /* fork_desc_reader: we don't even try to read descriptors over forked
    * children processes. */
    void fork_desc_reader() {
        return;
    }

    /* fork_int_reader: read an integer. */
    int fork_int_reader() {
        int res;
        blk_read(fork_read_fd, (char*) &res, sizeof(int));
        return res;
    }

    size_t fork_size_reader() {
        size_t res;
        blk_read(fork_read_fd, (char*) &res, sizeof(size_t));
        return res;
    }

    void* rpc_buf_reader(size_t sz)
    {
        return host_recv_buf(sandbox, sz);
    }

    /* rpc_desc_reader: construct the virtual descriptor table from the
    * sandbox. */
    void rpc_desc_reader() {
        // Read the number of descriptors.
        int num_descs = host_recv_int(sandbox);

        /* Read the virtual descriptor table from over the RPC. */
        int* virts;
        int* descs;
        host_recv_virt_table(sandbox, num_descs, &virts, &descs);

        // Set the virtual descriptor table.
        set_virt_descs(virts, descs, num_descs);
        return;
    }

    // Reads an unsigned integer over an RPC channel.
    int rpc_int_reader()
    {
        return host_recv_int(sandbox);
    }


    // rpc_size_reader: reads a size over an RPC channel.
    size_t rpc_size_reader()
    {
        return host_recv_size(sandbox);
    }

    typedef void* (buf_reader)(size_t);
    typedef void desc_reader();
    typedef int int_reader();
    typedef size_t size_reader();

  /* read_work: read from the server:
   *
   * -the virtual descriptor table
   *
   * -the return value
   * 
   * -the strategy state
   * 
   * Store the strategy state on the strategy stack.
   */
  iovec*
  read_work(
    buf_reader buf_rdr,
    desc_reader desc_rdr,
    int_reader int_rdr,
    size_reader sz_rdr)
  {
    // Desc reader: read the descriptor table.
    desc_rdr();

    /* Read the size of the result from the worker. */
    size_t res_sz = sz_rdr();

    /* Allocate a buffer big enough to hold the result, then read
     * data into it. */
    void* res_buf = buf_rdr(res_sz);

    /* Construct an iovec that holds the result. */
    iovec* work_res = (iovec*) malloc(sizeof(iovec));
    work_res->iov_base = res_buf;
    work_res->iov_len = res_sz;

    /* Allocate a strategy frame, read the strategy state from the
     * child, and store the state in the frame. */
    state_t child_state = int_rdr();
    strat_stack = push_strat_frame(child_state);
    return work_res;
  }

  /* cw_fork_setup: takes as input:
   *
   * -work: a work function that is to be executed after a fork.
   *
   * -args: a vector of arguments
   * 
   * -num_args: the number of arguments. Not used, only declare to be
   *  compatible with RPC setup function.
   *
   * Returns:
   *
   * -a iovec holding the return value of the work function.
   */
  iovec* cw_fork_setup(call_indx_t worker, iovec* args, int num_args)
  {
    /* Create a pipe for two-way communication between parent and
     * child.
     */
    printd(0, "fork: begin: " + int_to_string(getpid()) + "\n");

    trans_func = void_ptr_id;
    int pipe_ends[2];
    int pipe_status = pipe(pipe_ends);
    int read_end = pipe_ends[0];
    int write_end = pipe_ends[1];

    /* fork_res: stores the result of the fork. */
    iovec* fork_res;
    
    if (pipe_status) {
      fprintf(stderr, "cw_fork: failed to create pipe.\nAborting.\n");
      abort();
    }
    else {
      pid_t pid = fork();
      printd(1,
	    "cw_fork_setup: post fork: " + int_to_string(getpid()) + "\n");

      if (pid == -1) {
        // The fork failed.
        fprintf(stderr, "cw_fork: failed to fork.\nAborting.\n");
        abort();
      }
      else if (pid == 0) {
        /* We are the child. First, close half the pipe so that we can
         * only write. */
        printd(0, "fork: begin child " + int_to_string(getpid()) + " \n");
        close(read_end);
	
	// Do the work and it over the pipe.
	fork_write_fd = write_end;
	work_and_write(
            worker,
            args,
            fork_buf_writer,
            fork_desc_writer,
            fork_int_writer,
            fork_size_writer);
	
        close(write_end);
        printd(0, "fork: end child " + int_to_string(getpid()) + " \n");
        exit(0);
      }
      else {
        /* We are the parent. First, close the pipe so that we can
         * only read. */
        printd(1, "parent " + int_to_string(getpid()) + "\n");
        close(write_end);

	// Read information from the child worker.
	fork_read_fd = read_end;
	fork_res = 
            read_work(
                fork_buf_reader,
                fork_desc_reader,
                fork_int_reader,
                fork_size_reader);
        close(read_end);
	printd(1, "parent-side end\n");
      }
    }

    printd(0, "fork: end\n");
    return fork_res;
  }

  iovec*
  cw_rpc_setup(call_indx_t worker, iovec* args, int num_args)
  {
    size_t* len_p;

    // Build buffer of virtual file descriptors, array of file descriptors.
    int* virts;
    int* fds;
    int num_fds = serialize_virt_descs(&virts, &fds);

    /* Make an RPC call passing the number of file descriptors. */
    rpc_int(sandbox, worker, num_fds);

    // Send the virtual descriptor table.
    host_send_virt_table(sandbox, fds, virts, num_fds);

    // Send a vector holding the number of arguments.
    host_send_int(sandbox, num_args);

    // Build an array of the number of descriptors.
    // Send each argument.
    for (int arg_index = 0; arg_index < num_args; arg_index++) {
        struct iovec cur_arg = args[arg_index];
        host_send_size(sandbox, cur_arg.iov_len);
        host_send_buf(sandbox, cur_arg.iov_base, cur_arg.iov_len);
        printf("client: post send\n");
    }

    // Read return value from sandbox.
    return
        read_work(
            rpc_buf_reader,
            rpc_desc_reader,
            rpc_int_reader,
            rpc_size_reader);
  }

  void cw_desc(int c, int d) {
    return;
  }

  void cw_act(int i) {
    return;
  }

  /* cw_fork: sets the callee-translation function. */
  void cw_fork()
  {
    printd(1, "cw_fork: begin\n");
    setup_func = cw_fork_setup;
    trans_func = repl_marshaller;
    printd(1, "cw_fork: end\n");
    return;
  }

  /* cw_rpc: prepare to execute the next call via RPC.
   */
  void cw_rpc()
  {
    printd(1, "cw_rpc: execute\n");
    setup_func = cw_rpc_setup;
    trans_func = repl_marshaller;
    printd(1, "cw_rpc: end\n");
    return;
  }

  // Functions called by various marshaller and unmarshallers.
  void* int_to_voidp(int* ip) {
        return (void*) ip;
  }

  void* str_to_voidp(char** strp) {
        return (void*) *strp;
  }

  int voidpp_to_int(int* ip) {
        return *((int*) ip);
  }

  char* voidpp_to_str(void* p) {
        return (char*) p;
  }

  ssize_t int_size(int x) {
        return sizeof(int);
  }

  ssize_t str_size(char* p) {
        return strlen(p) + 1;
  }

  /* cw_extract_fpp: extract a descriptor from a FILE** into a
   * descriptor pointer. */
  void cw_extract_fpp(FILE* fp, int* dsc)
  {
    printd(1, "cw_extract_fpp: pre set\n");
    // printf("fileno: %d: ferror(fp): %d\n", fileno(fp), ferror(fp));
    *dsc = fileno(fp);
    printd(1, "cw_extract_fpp: post set\n");
    return;
  }

  // cw_extract_fd: extract a descriptor into a descriptor pointer.
  void store_fd(int fd, int* dsc)
  {
    *dsc = fd;
    return;
  }

  /* cw_extract_pcapp: extract a descriptor from a pcap_t into a
   * desctiptor pointer. */
  void cw_extract_pcapp(pcap_t* cap_p, int* dsc)
  {
    /* wrharris: commented for unit testing.
    FILE* pcap_f = pcap_file(cap_p);
    if (pcap_f) {
      *dsc = fileno(pcap_f);
    }
    else {
      *dsc = pcap_fileno(cap_p);
    }
    */

    return;
  }

  /* wg_dbg: general-purpose debugging function. */
  void wg_dbg(int code)
  {
    printf("wg_dbg: %d\n", code);
    return;
  }

  void wg_dbg_ptr(char* ptr)
  {
    printf("wg_dbg_ptr: %x\n", ptr);
    return;
  }

        /* (hypothetical) alternate entry point of the instrumented 
         * program. */
  int cap_main(int argc, char* argv[]) {
    printf("cap_main: enter\n");
    return 0;
  }
}
