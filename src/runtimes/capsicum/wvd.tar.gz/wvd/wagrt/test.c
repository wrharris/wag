#include <fcntl.h>

int main() {
        wg_init_strat("./a.out");
        struct iovec vec;
        int data;
        vec.iov_base = 42;
        vec.iov_len = sizeof(int);
        cw_rpc_setup(0, &vec, 1);
        return 0;
}
