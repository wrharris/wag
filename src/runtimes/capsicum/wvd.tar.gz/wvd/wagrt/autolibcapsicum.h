int
recv_int_rpc(
    struct lc_host* host, u_int32_t* op_buf, u_int32_t* seq_op_buf);

struct lc_sandbox* basic_start_sb(const char* sb_name, char* const argv[]);

// unblock_host: unblock the host by acking the RPC.
void unblock_host(struct lc_host* host, u_int32_t op, u_int32_t seq_op);

void* sb_recv_buf(struct lc_host* host, size_t sz);

int sb_recv_int(struct lc_host* host);

size_t sb_recv_size(struct lc_host* host);

void
sb_recv_virt_table(
    struct lc_host* host, int num_fds, int** fds, int** virts);

void sb_send_buf(struct lc_host* host, void* buf, size_t sz);

void sb_send_int(struct lc_host* host, int);

void sb_send_size(struct lc_host* host, size_t num_fds);

void
sb_send_virt_table(
    struct lc_host* host, int* virts, int* descs, int num_fds);

void rpc_int(struct lc_sandbox* sb, int worker, int i);

void* host_recv_buf(struct lc_sandbox* sb, size_t size);

int host_recv_int(struct lc_sandbox* sb);

size_t host_recv_size(struct lc_sandbox* sb);

void
host_recv_virt_table(
    struct lc_sandbox* sb, int num_fds, int** virts, int** fds);

void host_send_buf(struct lc_sandbox* sb, void* p, size_t sz);

void host_send_int(struct lc_sandbox* sb, int i);

void host_send_size(struct lc_sandbox* sb, size_t num_args);

void
host_send_virt_table(
    struct lc_sandbox* sb, int* fds, int* virts, int num_fds);

