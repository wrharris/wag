#!/usr/local/bin/bash

clang -c -emit-llvm model_php.c -o model.bc
llvm-link cw_shims.bc model.bc -o model_shims.bc
