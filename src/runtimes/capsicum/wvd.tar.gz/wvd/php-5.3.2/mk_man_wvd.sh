#!/usr/local/bin/bash

gcc -c cw_shims_wvd.c
clang++ -L/usr/local/lib -lcapsicum cw_shims_wvd.o php-cgi.bc -lcrypt -liconv -lm -lxml2 -lz -lxml2 -o sapi/cgi/php-cgi
