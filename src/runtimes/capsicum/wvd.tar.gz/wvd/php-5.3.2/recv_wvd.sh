#!/usr/local/bin/bash

wag_root="~/private/research/policy_weaving/generator/implementation/wag/"

scp wrharris@tortoise.cs.wisc.edu:"$wag_root/lib/*instr_store.bc" .
scp wrharris@tortoise.cs.wisc.edu:"$wag_root/test/benchmarks/php/*.bc.wvd.bc" .
