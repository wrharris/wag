#include "assert.h"
#include "fcntl.h"
#include "stdio.h"
#include "unistd.h"

extern int cw_act(int);
extern int shim_open(const char*, int);

int main(int argc, char* argv[]) {
    cw_act(8);
    shim_open("foo", 0);
	
    return 0;
}
