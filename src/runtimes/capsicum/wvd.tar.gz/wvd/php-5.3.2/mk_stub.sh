#!/usr/local/bin/bash

clang -c -emit-llvm -o model_php.bc model_php.c
clang -c -emit-llvm -o cw_shims.bc cw_shims.c
llvm-link -o model_shims.bc cw_shims.bc model_php.bc
