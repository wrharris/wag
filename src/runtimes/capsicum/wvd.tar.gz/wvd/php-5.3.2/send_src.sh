#1/usr/local/bin/bash

scp cgi_main_shims.bc php_core.bc wrharris@tortoise.cs.wisc.edu:~/private/research/policy_weaving/generator/implementation/wag/test/benchmarks/php/
