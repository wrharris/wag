<?
$rootpath="";

function DisplayFile($fname)
{
    /*read file*/
    $text = file_get_contents($fname);

    /*write file*/
    echo $text;
}

DisplayFile("header.html");
?>

<p>
Some text in the middle. This is some middle text.
</p>

<?
DisplayFile("footer.html");
?>