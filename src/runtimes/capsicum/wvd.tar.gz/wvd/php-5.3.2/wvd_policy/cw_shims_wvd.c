#include <assert.h>
#include <fcntl.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>

#include <sys/uio.h>
#include <libcapsicum.h>

int shim_open(const char* path, int flags, ...);
FILE* shim_fopen(const char* path, const char * mode);

// Functions for testing shim_open.
void test_0() {
	char buf[80];
	memset(buf, 0, 20);
	int fd = shim_open("/tmp/foo.txt", O_RDONLY);
	printf("test 0: shim_open returned fd %d\n", fd);
	read(fd, buf, 80);
	printf("test 0: foo text: %s\n", buf);
	close(fd);
	return;
}

/* Security shims for rewriting the program for Capsicum. */

// Policy property checks.
int is_wl_sys_lib(const char* path) {
  return 0;
}

int is_php_mw_config(const char* path) {
  return 0;
}

int is_mw_php(const char* path) {
  return 0;
}

int is_skin(const char* path) {
  return 0;
}

int is_scratch(const char* path) {
  int is_scratch =
    (strstr(path, "/tmp") == path) 
    || (strstr(path, "/var/tmp") == path)
    || (strstr(path, "/usr/local/www/mediawiki/images/") == path);
  
  return is_scratch;
}

/* shim_open: a shim for opening file descriptors.
 * 
 * Arguments: same as inputs to open.
 * 
 * Returned value: descriptor returned by open, wrapped as a capability.
 */
int core_open(const char* path, int flags, ...) {
  // Check if path satisfies each policy condition. 

  // If the flag includes that the file should be created:
  printf("core_open: begin\n");
  fflush(stdout);
  int fd;

  va_list opt_args;
  va_start(opt_args, flags);

  if (flags & O_CREAT) {
    /* then grab the optional mode argument and pass the whole thing
     * to open. */
    mode_t mode = va_arg(opt_args, int);
    fd = open(path, flags, mode);
  }
  else {
    // else pass path and flags to open.
    fd = open(path, flags);
  }

  printf("core_open: pre req checks\n");
  fflush(stdout);
  // Check what policy properties the path satisfies.
  if (is_wl_sys_lib(path)) {
    lc_limitfd(fd, CAP_READ | CAP_SEEK);
  }
  else if (is_php_mw_config(path)) {
    lc_limitfd(fd, CAP_READ | CAP_SEEK);
  }
  else if (is_mw_php(path)) {
    lc_limitfd(fd, CAP_READ | CAP_SEEK);
  }
  else if (is_skin(path)) {
    lc_limitfd(fd, CAP_READ | CAP_SEEK);
  }
  else if (is_scratch(path)) {
	printf("is_scratch: yes\n");
    lc_limitfd(fd, CAP_SEEK | CAP_READ | CAP_WRITE);
  }
  else {
    lc_limitfd(fd, 0);
  }

  return fd;
}

// sb_open: sandbox interface to the open function.
void sb_open() {
  u_int32_t op_buf;
  u_int32_t seq_buf;
  u_char* bp;
  size_t size_buf;
  struct lc_host* host;
  int fd_buf;
  int num_fds;

  lcs_get(&host);

  printf("sb_open: begin polling\n");
  fflush(stdout);
  while (1) {
    printf("sb_open: pre rpc recv\n");
    fflush(stdout);
    num_fds = 0;
    int recv_err =
      lcs_recvrpc_rights(host, // the host object
    		         &op_buf, // buffer holding the operand code	
		         &seq_buf, // buffer holding the sequence num
		         &bp,	// buffer holding argument iovec (?)
		         &size_buf,
			&fd_buf,
			&num_fds);
	// buffer holding some size
    printf("sb_open: post rpc recv: buf size: %d\n", size_buf);
    fflush(stdout);

    if (recv_err == -1) {
      fprintf(stderr, "sb_open: rpc_recv failed.\n");
      printf("sb_open: rpc_recv failed.\n");
      fflush(stdout);
      abort();
    }
    else {
      // Call core open function.
      printf("pre assert op_buf is 0\n");
      fflush(stdout);
      assert(op_buf == 0);
      printf("post assert op_buf is 0\n");
      fflush(stdout);

      // Marshall arguments to the core open function.
      printf("sb_open: pre marshall arguments\n");
	fflush(stdout);
      struct iovec* args = (struct iovec*) bp;
      char* path = (char*) bp;
	printf("recved path: %s\n", path);
	fflush(stdout);
      int flags = O_RDONLY;
      printf("sb_open: flags value: %d\n", flags);
      fflush(stdout);

      // Get a descriptor from the core open function.
      printf("sb_open: pre core open\n");
	fflush(stdout);
      int fd = core_open(path, flags);

      // Send descriptor back over RPC.
      struct iovec ret_buf;
	ret_buf.iov_base = 0;
	ret_buf.iov_len = 0;

      printf("sb_open: fd returned by core_open %d\n", fd);
      fflush(stdout);
      int send_err =
        lcs_sendrpc_rights(host,    // host
			   op_buf,  // operation number (?)
			   seq_buf, // sequence number (?)
			   &ret_buf, // pointer to return iovectors
			   1, // number of return iovectors
			   &fd,
			   1);
      printf("sb_open: post call lcs_sendrpc_rights\n");
      fflush(stdout);
      if (send_err == -1) {
        fprintf(stdout, "sb_open: rpc_send failed\n");
	fflush(stdout);
        abort();
      }
    }
  }

	// This should never be reached.
	return;
}

struct lc_sandbox* sb;

// sb_init: initiaize the sandbox.
void sb_init(char* argv[]) {
  printf("sb_init: begin\n");
  fflush(stdout);
  // write(fileno(stdout), "foobar\n", 7);
  if (ld_insandbox()) {
    // If we're in the sandbox, then start servicing requests.
	printf("sb_init: in sandbox\n");
	fflush(stdout);
	sb_open(); 
  }
  else {
    // If we're not in the sandbox, then launch the sandbox.
	printf("argv[0]: %s\n", argv[0]);
	int start_err = 
		lch_start(argv[1],
		argv, // argv
		LCH_PERMIT_STDOUT,
		0, // list of initial file descriptors
		&sb); // output argument for sandbox
	if (start_err) {
		fprintf(stderr, "error starting shim_open sandbox\n");
		abort();
	}
	else {
		printf("calling cap_enter\n");
		cap_enter();
		test_0();
		return;
	}
  }

  return;
}

int shim_open(const char* path, int flags, ...) {
  // Build an argument iovec.

  printf("shim_open: flags: %d\n", flags);
  struct iovec* args = (struct iovec*) malloc(2 * sizeof(struct iovec));

  // Build an iovec holding the pathname.
  args[0].iov_base = (void*) path;
  args[0].iov_len = strlen(path) + 1;

  // Build an iovec holding the flags.
  args[1].iov_base = (void*) &flags;
  args[1].iov_len = sizeof(int);

  // Allocate buffers for returning data values.
  struct iovec ret_buf;
  size_t rlp;

  // Allocate buffers for returning file descriptors.
  int ret_fd_buf;
  int ret_fd_num = 2;
  printf("shim_open: pre RPC call\n");
  int rpc_err = 
    lch_rpc_rights(sb, // sandbox
  		   0, // operation number
		   args, // argument vector
                   1, // size of argument vector
		   0,
		   0,
		   &ret_buf, // vector of return values
		   1,
                   &rlp,
		&ret_fd_buf,
		&ret_fd_num); // size of return vector
  sleep(1);
  if (rpc_err == -1) {
    fprintf(stderr, "shim_open: error making RPC call.\n");
    abort();
  }
  else {
    // Receive a file descriptor from the core open function.
    return ret_fd_buf;
  }
}

/* shim_fopen: a security shim for fopen.
 * 
 * Parameters: same as fopen.
 *
 * Return: a FILE* constructed from a file descriptor that is a
 * capability.
 */
FILE* shim_fopen(const char* path, const char * mode) {
  /* flags: file flags defined by the mode, used to open the file
   * descriptor. */
  int flags = 0;

  if (mode[0] == 'r') {
    if (mode[1] == '+') {
      flags = O_RDWR;
    }
    else {
      flags = O_RDONLY;
    }
  }
  else if (mode[1] == 'w') {
    if (mode[1] == '+') {
      flags = O_RDWR | O_CREAT;
    }
    else {
      flags = O_WRONLY;
    }
  }
  else if (mode[0] == 'a') {
    if (mode[1] == '+') {
      flags = O_RDWR | O_APPEND | O_CREAT;
    }
    else {
      flags = O_APPEND;
    }
  }

  /* fd: capability created by the shim. */
  int fd = shim_open(path, flags, 0777);

  /* Construct a FILE* from the capability. */
  return fdopen(fd, mode);
}

/* is_db: decide if a socket address refers to the database server. */
int is_db(const struct sockaddr* name) {
  // If the socket address points to the localhost:
  char nm_buf[10];
  getnameinfo(name, sizeof(*name), nm_buf, 10, 0, 0, 0);
  
  int is_db;
  if (!strcmp(nm_buf, "localhost")) {
    // If the socket address is an internet address:
    if (name->sa_family == AF_INET) {
      struct sockaddr_in* name_in = (struct sockaddr_in*) name;
      is_db = name_in->sin_port == htons(5432);
    }
    else {
      is_db = 0;
    }
  }
  else {
    is_db = 0;
  }

  return is_db;
}

/* shim_socket:
 * 
 * Parameters: same as socket.
 * 
 * Returns: a capability with managed rights.
 */
int shim_connect(int s, const struct sockaddr* name, socklen_t namelen) {
  // Name the socket as a policy descriptor.

  // Connect the socket. If connection throws an error:
  int err = connect(s, name, namelen);
  if (err) {
    // then just bail out.
    return err;
  }
  else {
    // otherwise, check if the socket address is the database server.
    if (is_db(name)) {
    }
    else {
    }
  }

  return err;
}

/* shim_socket: a wrapper around socket. Allows the weave to call
 * primitives that manage the rights of the socket. */
int shim_socket(int domain, int type, int protocol) {
  int sock = socket(domain, type, protocol);
  return sock;
}

/* shim_socketpair: a wrapper around socketpair. Allows the weaver to
 * insert calls to primitives that manage the rights of the pair of
 * sockets. */
int shim_socketpair(int d, int type, int protocol, int* sv) {
  int err = socketpair(d, type, protocol, sv);
  return err;
}
