#include <fcntl.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>

// Include the policy validators.
#include "pol_validators.h"

int shim_open(const char* path, int flags, ...);
FILE* shim_fopen(const char* path, const char * mode);

extern void cw_act(int);
extern void cw_desc(int, int);
extern int virt_open(const char*, int, ...);
extern FILE* virt_fdopen(int, const char*);

/* Security shims for rewriting the program for Capsicum. */

/* shim_open: a shim for opening file descriptors.
 * 
 * Arguments: same as inputs to open.
 * 
 * Returned value: descriptor returned by open, wrapped as a capability.
 */
int shim_open(const char* path, int flags, ...) {
  // Check if path satisfies each policy condition. 

  // If the flag includes that the file should be created:
  int fd;

  va_list opt_args;
  va_start(opt_args, flags);

  cw_act(0);

  if (flags & O_CREAT) {
    /* then grab the optional mode argument and pass the whole thing
     * to open. */
    mode_t mode = va_arg(opt_args, int);
    fd = virt_open(path, flags, mode);
  }
  else {
    // else pass path and flags to open.
    fd = virt_open(path, flags);
  }

  cw_desc(0, fd);

  // Check what policy properties the path satisfies.
  if (is_wl_sys_lib(path)) {
    cw_act(1);
  }
  else if (is_php_mw_config(path)) {
    cw_act(2);
  }
  else if (is_mw_php(path)) {
    cw_act(3);
  }
  else if (is_skin(path)) {
    cw_act(4);
  }
  else if (is_scratch(path)) {
    cw_act(5);
  }
  else {
    cw_act(6);
  }

  cw_act(7);

  return fd;
}

/* shim_fopen: a security shim for fopen.
 * 
 * Parameters: same as fopen.
 *
 * Return: a FILE* constructed from a file descriptor that is a
 * capability.
 */
FILE* shim_fopen(const char* path, const char * mode) {
  /* flags: file flags defined by the mode, used to open the file
   * descriptor. */
  int flags = 0;

  if (mode[0] == 'r') {
    if (mode[1] == '+') {
      flags = O_RDWR;
    }
    else {
      flags = O_RDONLY;
    }
  }
  else if (mode[1] == 'w') {
    if (mode[1] == '+') {
      flags = O_RDWR | O_CREAT;
    }
    else {
      flags = O_WRONLY;
    }
  }
  else if (mode[0] == 'a') {
    if (mode[1] == '+') {
      flags = O_RDWR | O_APPEND | O_CREAT;
    }
    else {
      flags = O_APPEND;
    }
  }

  /* fd: capability created by the shim. */
  int fd = shim_open(path, flags, 0777);

  /* Construct a FILE* from the capability. */
  return virt_fdopen(fd, mode);
}

/* is_db: decide if a socket address refers to the database server. */
int is_db(const struct sockaddr* name) {
  // If the socket address points to the localhost:
  char nm_buf[10];
  getnameinfo(name, sizeof(*name), nm_buf, 10, 0, 0, 0);
  
  int is_db;
  if (!strcmp(nm_buf, "localhost")) {
    // If the socket address is an internet address:
    if (name->sa_family == AF_INET) {
      struct sockaddr_in* name_in = (struct sockaddr_in*) name;
      is_db = name_in->sin_port == htons(5432);
    }
    else {
      is_db = 0;
    }
  }
  else {
    is_db = 0;
  }

  return is_db;
}

/* shim_socket:
 * 
 * Parameters: same as socket.
 * 
 * Returns: a capability with managed rights.
 */
int shim_connect(int s, const struct sockaddr* name, socklen_t namelen) {
  // Name the socket as a policy descriptor.
  // cw_desc(1, s);

  // Connect the socket. If connection throws an error:
  int err = connect(s, name, namelen);
  if (err) {
    // then just bail out.
    return err;
  }
  else {
    // otherwise, check if the socket address is the database server.
    if (is_db(name)) {
      //cw_act(8);
    }
    else {
      // cw_act(9);
    }
  }

  return err;
}

/* shim_socket: a wrapper around socket. Allows the weave to call
 * primitives that manage the rights of the socket. */
int shim_socket(int domain, int type, int protocol) {
  int sock = socket(domain, type, protocol);
  // cw_desc(2, sock);
  return sock;
}

/* shim_socketpair: a wrapper around socketpair. Allows the weaver to
 * insert calls to primitives that manage the rights of the pair of
 * sockets. */
int shim_socketpair(int d, int type, int protocol, int* sv) {
  int err = socketpair(d, type, protocol, sv);
  // cw_desc(3, sv[0]);
  // cw_desc(4, sv[1]);
  return err;
}
