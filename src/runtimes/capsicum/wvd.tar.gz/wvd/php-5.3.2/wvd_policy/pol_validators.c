#include <string.h> 

// Policy property checks.
int is_wl_sys_lib(const char* path) {
  return !(strcmp(path, "/tmp/syslib"));
}

int in_string_array(const char* needle, char** haystack)
{
    int found = 0;
    while (*haystack)
    {
        if (!strcmp(needle, *haystack))
        {
            found = 1;
            break;
        }
        else
        {
            haystack++;
        }
    }

    return found;
}

int prefix_of_str(const char** pres, const char* haystack)
{
    int found = 0;
    while (*pres)
    {
        if (strstr(haystack, *pres) == haystack)
        {
            found = 1;
            break;
        }
        else
        {
            pres++;
        }
    }

    return found;
}

int is_php_mw_config(const char* path) {
    // Check if the file path is in some whitelist.
    char* config_files[5] = 
        { "./php-cgi-fcgi.ini",
        "/usr/local/lib/php-cgi-fcgi.ini",
        "./php.ini",
        "/usr/local/lib/php.ini",
        0
        };
    return in_string_array(path, config_files);
}

/* iw_mw_php: decide if a path points to a mediawiki PHP file. */
int is_mw_php(const char* path) {
    char* php_files[3] =
        { "header.html",
            "footer.html",
            0
        };
    return in_string_array(path, php_files);
}

/* is_skin: decide if a path points to a skin file. */
int is_skin(const char* path) {
  return 0;
}

int is_scratch(const char* path) {
    const char* scratch_dirs[4] =
        { "/tmp",
          "/var/tmp",
          "/usr/local/www/mediawiki/images",
          0
        };
    return prefix_of_str(scratch_dirs, path);
}


