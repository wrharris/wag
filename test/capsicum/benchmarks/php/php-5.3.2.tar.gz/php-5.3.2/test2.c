#include <stdio.h>

int main()
{
	int fd = dup(1);
	close(1);
	write(fd, "foo\n", 4);
	return 0;
}
