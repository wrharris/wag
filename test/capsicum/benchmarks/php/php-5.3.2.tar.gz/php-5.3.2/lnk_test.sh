#!/usr/local/bin/bash
WAGRT_DIR=~/wvd/wagrt/

clang -c test.bc.wvd.bc -o test.wvd.o
clang -c test.bc.instr_store.bc -o test.instr_store.o
clang -c test.bc.llvm_instr_store.bc -o test.llvm_instr_store.o

g++ \
	    -L/usr/lib \
	    -L/usr/local/lib \
	    -lcapsicum \
	    test.instr_store.o \
	    test.llvm_instr_store.o \
		$WAGRT_DIR/autolibcapsicum.o \
	    $WAGRT_DIR/weaver_runtime.o \
	    test.wvd.o \
	    -o test.wvd

