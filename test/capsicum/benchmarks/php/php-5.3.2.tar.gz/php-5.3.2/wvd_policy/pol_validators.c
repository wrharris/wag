#include <netdb.h>
#include <netinet/in.h>

#include <stdio.h>
#include <string.h> 
#include <sys/socket.h>
#include <sys/types.h>

/* is_db: decide if a socket address refers to the database server. */
int is_db2(const struct sockaddr* name) {
  // If the socket address points to the localhost:
  char nm_buf[10];
  getnameinfo(name, sizeof(*name), nm_buf, 10, 0, 0, 0);
  
  int is_db;
  if (!strcmp(nm_buf, "localhost")) {
    // If the socket address is an internet address:
    if (name->sa_family == AF_INET) {
      struct sockaddr_in* name_in = (struct sockaddr_in*) name;
      is_db = name_in->sin_port == htons(5432);
    }
    else {
      is_db = 0;
    }
  }
  else {
    is_db = 0;
  }

  return is_db;
}

int is_db(const struct sockaddr* name)
{
	return 1;
}

// Policy property checks.
int is_wl_sys_lib(const char* path) {
  return !(strcmp(path, "/tmp/syslib"));
}

int in_string_array(const char* needle, char** haystack)
{
    int found = 0;
    while (*haystack)
    {
        if (strstr(*haystack, needle))
        {
            found = 1;
            break;
        }
        else
        {
            haystack++;
        }
    }

    return found;
}

int prefix_of_str(const char** pres, const char* haystack)
{
    int found = 0;
    while (*pres)
    {
        if (strstr(haystack, *pres) == haystack)
        {
            found = 1;
            break;
        }
        else
        {
            pres++;
        }
    }

    return found;
}

int is_php_mw_config(const char* path) {
    // Check if the file path is in some whitelist.
    char* config_files[7] = 
        { "./php-cgi-fcgi.ini",
        "/usr/local/lib/php-cgi-fcgi.ini",
        "./php.ini",
        "/usr/local/lib/php.ini",
		"header.html",
	    "bar.html",
        0
        };
	int res = in_string_array(path, config_files);
    return res;
}

/* iw_mw_php: decide if a path points to a mediawiki PHP file. */
int is_mw_php(const char* path) {
    char* php_files[3] =
        { "foo.html",
          "bar.html",
            0
        };
    return in_string_array(path, php_files);
}

/* is_skin: decide if a path points to a skin file. */
int is_skin(const char* path) {
  return 0;
}

int is_scratch(const char* path) {
    const char* scratch_dirs[4] =
        { "/tmp",
          "/var/tmp",
          "/usr/local/www/mediawiki/images",
          0
        };
    return prefix_of_str(scratch_dirs, path);
}


