#include <string.h> 

// Policy property checks.
int is_db(const struct sockaddr* name);

int is_wl_sys_lib(const char* path);

int is_php_mw_config(const char* path);

int is_mw_php(const char* path);

int is_skin(const char* path);

int is_scratch(const char* path);
