#include <stdio.h>

extern FILE* shim_fopen(const char*, const char*);

void f()
{
	FILE* f = shim_fopen("foo", "rd");
	return;
}
