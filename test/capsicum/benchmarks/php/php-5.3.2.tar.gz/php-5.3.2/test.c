#include <stdio.h>
#include <sys/socket.h>

extern void cw_act(int);

int main(int argc, char* argv[])
{
	int sock = socket(AF_INET, SOCK_STREAM, 0);
	printf("socket: %d\n", sock);
	struct sockaddr a;
	char* data;
	a.sa_family = AF_INET;
	int rc = connect(sock, &a, 14);
	printf("connect status: %d\n", rc);
	return 0;
}
