#!/usr/local/bin/bash
for f in *.phpt
do
	../php-cgi < $f
done
