#include "assert.h"
#include "fcntl.h"
#include "stdio.h"
#include "unistd.h"

extern void cw_act(int);
extern int shim_fopen(const char*, char*);

void f();

void g()
{
	int x;
	if (x)
	{
		f();
	}
	
	return;
}

int main(int argc, char* argv[]) {
    cw_act(8);
	g();
    return 0;
}
