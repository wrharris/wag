#include <stdio.h>
#include <sys/socket.h>

extern void cw_act(int);

int shim_connect2(int sock, struct sockaddr sa, socklen_t sl)
{
	cw_act(1);
	return 0;
}

int main(int argc, char* argv[])
{
	cw_act(0);
	int sock = socket(AF_INET, SOCK_STREAM, 0);
	printf("socket: %d\n", sock);
	struct sockaddr a;
	char* data;
	a.sa_family = AF_INET;
	int rc = shim_connect2(sock, a, 14);
	printf("connect status: %d\n", rc);
	return 0;
}
